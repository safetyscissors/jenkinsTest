<?php
require('authCheck.php');
if(!isset($USER->id)) return;
require('queries/orderQueries.php');
$PAGE->id='orderGet';

//get inputs. requires listId
$requiredField='orderId';
$input='';
if(isset($_GET[$requiredField]) && !empty($_GET[$requiredField])){
    $input=$_GET[$requiredField];
}else{
    return errorHandler("Missing $requiredField", 503);
}

//setup for query
$stmt = getOrder($DB, $input);
if(!$stmt) return; // stmt already send error.
if(!$stmt->execute()) return errorHandler("failed to get this list $stmt->errno: $stmt->error");
//format results
$data = array();
$stmt->bind_result($data['orderId'],$data['orderNumber'],$data['orderDate'],$data['deliveryDate'],$data['season'],$data['notes'],$data['status'],$data['growerId'],$data['growerName'],$data['variety'],$data['location'],$data['plantsPerBox'],$data['boxQuantity']);

/* fetch values */
$stmt->fetch();
$stmt->close();

if(isset($data['orderId']) && !empty($data['orderId'])){
    $ordersStmt = getOrderProducts($DB, $data['orderId']);
    if(!$ordersStmt) return; // stmt already send error.
    if(!$ordersStmt->execute()) return errorHandler("failed to get sub orders $ordersStmt->errno: $ordersStmt->error");

    $orderData = array();
    $ordersStmt->bind_result($orderData['productId'],$orderData['variety'],$orderData['location'],$orderData['boxQuantity'],$orderData['plantsPerBox'],$orderData['plantQuantity']);

    $data['orders'] = array();
    while($ordersStmt->fetch()){
        array_push($data['orders'],arrayCopy($orderData));
    }
}

echo json_encode($data);

function arrayCopy( array $array ) {
    $result = array();
    foreach( $array as $key => $val ) {
        if( is_array( $val ) ) {
            $result[$key] = arrayCopy( $val );
        } elseif ( is_object( $val ) ) {
            $result[$key] = clone $val;
        } else {
            $val = utf8_encode($val);
            $result[$key] = $val;
        }
    }
    return $result;
}
?>