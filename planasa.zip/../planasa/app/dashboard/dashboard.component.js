angular.module('dashboard').component('dashboard',
    {
        templateUrl: 'app/dashboard/dashboard.template.html',
        controller: function($location, $http){
            //set menu item
            INDEXPAGE.setSelectedNav('dash');
            function ERRORHANDLER(res){
                if(res.status==401) $location.url('login');
                else if(res.status==503) console.log(res.data);
                else console.log(res);
            }
            $http.get('server/userlist').then(function(res){
            }, ERRORHANDLER);
        }


    });