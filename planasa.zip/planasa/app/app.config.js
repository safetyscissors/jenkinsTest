angular.
module('planasa').
config(['$locationProvider', '$routeProvider',
    function config($locationProvider, $routeProvider) {
        $locationProvider.hashPrefix('!');

        $routeProvider.
        when('/phones', {
            template: '<phone-list></phone-list>'
        }).
        when('/phones/:phoneId', {
            template: '<phone-detail></phone-detail>'
        })

        .when('/',                              { template: '<dashboard layout="column" flex></dashboard>' })
        .when('/grower/',                       { template: '<client-list layout="row" flex></client-list>' })
        .when('/grower/:clientId',              { template: '<client-list layout="row" flex></client-list>' })
        .when('/users/',                        { template: '<user-list layout="row" flex></user-list>' })
        .when('/users/:userId',                 { template: '<user-list layout="row" flex></user-list>' })

//        .when('/client/:clientId',              { template: '<client-detail></client-detail>' })
        .when('/orders/',                       { template: '<order-list layout="row" flex></order-list>' })
        .when('/orders/:orderId',               { template: '<order-detail layout="row" flex></order-detail>' })
        .when('/orders/search/:query',          { template: '<order-list layout="row" flex></order-list>' })
        .when('/orders/client/:clientId',       { template: '<client-order-list layout="row" flex></client-order-list>' })
        .when('/fulfillment/',                  { template: '<fulfillment-list layout="row" flex></fulfillment-list>' })
        .when('/fulfillment/:fulfillmentId',    { template: '<fulfillment-detail layout="row" flex></fulfillment-detail>' })
        .when('/fulfillment/order/:orderId',    { template: '<order-fulfillment-list layout="row" flex></order-fulfillment-list>' })
        .when('/fulfillment/client/:clientId',  { template: '<client-fulfillment-list layout="row" flex></client-fulfillment-list>' })
        .when('/fulfillment/search/:query',     { template: '<fulfillment-list layout="row" flex></fulfillment-list>' })
        .when('/products/',                     { template: '<products layout="row" flex></products>'})
        .when('/products/:productId',           { template: '<products layout="row" flex></products>'})
        .when('/report/',                       { template: '<report layout="row" flex></report>'})
        .when('/report/grower/',                { template: '<report-grower layout="row" flex></report-grower>'})
        .when('/report/grower/all',             { template: '<report-grower-all layout="row" flex></report-grower-all>'})

        .when('/login/',                        { template: '<login layout="column" flex></login>'})
        .when('/logout/',                       { template:'<logout></logout>'})
        .otherwise('/');

    }
]);
