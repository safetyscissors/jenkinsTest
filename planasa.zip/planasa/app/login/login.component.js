angular.module('login').component('login',
    {
        templateUrl: 'app/login/login.template.html',
        controller: function($http, $scope, $location){
            $scope.submit = function(login){
                var data = login;
                $http.post('server/auth', data).then(
                    function(res){
                        $location.url('dashboard');
                    },
                    function(res){
                        console.log(res);
                    }
                );
            }
        }
    });