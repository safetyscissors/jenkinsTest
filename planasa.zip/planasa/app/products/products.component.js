angular.module('products').component('products',
    {
        templateUrl: 'app/products/products.template.html',
        controller: function($routeParams, $http, $scope, $location, $mdDialog, $mdToast){
            var _this = this;
            _this.productId = $routeParams['productId'];

            //set menu item
            INDEXPAGE.setSelectedNav('prod');

            function ERRORHANDLER(res){
                if(res.status==401) $location.url('login');
                else if(res.status==503) console.log(res.data);
                else console.log(res);
            }

            $scope.updateList = function(isNew){
                $http.get('server/productlist').then(function (response) {
                    _this.products = response.data;
                    $scope.products = _this.products;

                    //build list of products/locations
                    var locations = [];
                    for(var i=0;i<_this.products.length;i++){
                        var loc = _this.products[i].location.replace(' ','');
                        if(!locations[loc]) locations[loc] = _this.products[i].location;
                    }

                    $scope.locations = [];
                    for(var key in locations){
                        $scope.locations.push(locations[key]);
                    }

                    //set selected
                    if($scope.selected){ $scope.setSelected($scope.selected) }
                    else if($routeParams['productId']){$scope.setSelected({productId:$routeParams['productId']})}


                }, ERRORHANDLER);
            };

            $scope.setSelected = function(e){
                if(!e.productId) return console.log('No productId');

                //$location.path('grower/'+e.growerId, false);
                if(e.productId === 'new') return $scope.selected = e;

                $http.get('server/product?productId='+e.productId).then(function(res){
                    var product = res.data[0];
                    //temporary todo
                    $scope.fields = 'to be added later';

                    $scope.selected = product;
                    $scope.filter.location = product.location;

                }, ERRORHANDLER);
            };

            $scope.saveForm = function(e){
                if(!e.productId) return console.log('No productId');
                var httpReq = {
                    data:e,
                    url:'server/product',
                    method:'put'
                };

                if(e.productId==='new') httpReq.method = 'post';

                $http(httpReq).then(function(res){
                    $mdToast.show(
                        $mdToast.simple()
                            .textContent('Saved')
                            .position('top right')
                            .hideDelay(3000)
                    );
                    if(res.data.id) e.productId = res.data.id;
                    $scope.updateList(e.productId==='new');
                }, ERRORHANDLER);
            };

            $scope.addNewProduct = function(){
                $scope.setSelected({productId:'new'})
            };

            $scope.showConfirm = function(e){
                var confirm = $mdDialog.confirm()
                    .title('Are you sure you want to delete '+$scope.selected.variety+'?')
                    .ariaLabel('Delete Product')
                    .targetEvent(e)
                    .ok('Delete')
                    .cancel('Keep');

                $mdDialog.show(confirm).then(function() {
                    var data = $scope.selected;
                    $scope.setSelected({productId:'new'})

                    /*
                    for (var i = 0; i < _this.clients.length; i++) {
                        if (_this.clients[i].productId == data.productId) {
                            $scope.selected = _this.clients[previous];
                        }else{
                            previous = i;
                        }
                    }
                    */

                    $http({
                        method:'delete',
                        data:data,
                        url:'server/product'
                    }).then(function(res){
                        $scope.updateList();
                    }, ERRORHANDLER);
                });
            };

            //init
            $scope.updateList();
        }
    });