<?php
    $data = require('../server/services/fulfillmentReceipt.php');
?>

<!DOCTYPE html>
<html>
<head>
    <title>Receipt</title>
    <link href="structure.css" rel="stylesheet" />
</head>
<body>
<div class="receiptContainer">
    <div class="title">Planasa Receipt</div>
    <div class="header">
        <div class="info">
            <ul>
                <li><span class="key">Customer:</span>      <?php echo $data['growerName'];?></li>
                <li><span class="key">Order Number:</span>  <?php echo $data['orderNumber'];?></li>
                <li><span class="key">Order Date:</span>    <?php echo $data['orderDate'];?></li>
                <li><span class="key">Shipment Number:</span><?php echo $data['fulfillmentNumber'];?></li>
                <li><span class="key">Shipment Date:</span> <?php echo $data['createdDate'];?></li>
            </ul>
        </div>
        <div class="pallets">
            <?php buildPallets($data['fulfillments']); ?>
        </div>
        <div style="clear:both;margin-bottom:30px;"></div>
    </div>


    <div class="main">
        <table >
            <tr>
                <th>Variety</th>
                <th>Location</th>
                <th>Boxes</th>
                <th>Plants</th>
            </tr>
            <?php buildTable($data['fulfillments']); ?>
        </table>

    </div>
</div>
</body>
</html>