angular.module('orderList').component('orderList',
    {
        templateUrl: 'app/order/order-list.template.html',
        controller: function ($routeParams, $http, $scope, $location, $mdDialog, $mdToast) {
            var _this = this;

            //set menu item
            INDEXPAGE.setSelectedNav('order');

            function ERRORHANDLER(res) {
                if (res.status == 401) $location.url('login');
                else if (res.status == 503) console.log(res.data);
                else console.log(res);
            }

            $scope.searchList = function(){
                if(!$scope.searchText) $scope.searchText = "";
                var search ='?status='+$scope.searchStatus+'&search='+$scope.searchText;
                $http.get('server/ordersearch'+search).then(loadListing, ERRORHANDLER);

            };

            $scope.bigSearch = function(){
                $scope.searchSizeClass = "big";
            };
            $scope.smallSearch = function(){
                if($scope.searchText && $scope.searchText.length>0) return;
                $scope.searchSizeClass = "small";
            };

            $scope.loadDetail = function(e){
                if(e.orderId){
                    $location.url('orders/'+e.orderId);
                }else{
                    console.log('Missing order id');
                }
            };

            $scope.updateList = function(){
                if($routeParams['query']){
                    console.log('querying:',$routeParams['query']);
                    $scope.searchText = $routeParams['query'];
                    $scope.searchStatus = 'all';
                    $scope.searchList();
                }else {
                    $http.get('server/orderlist2').then(loadListing, ERRORHANDLER);
                }
            };

            function loadListing(res){
                $scope.orders = res.data;
                if(!$scope.searchStatus) $scope.searchStatus = "all";

                //shorten notes field to elipses
                for(var i=0;i<$scope.orders.length;i++){
                    var status = $scope.orders[i]['status'];
                    $scope.orders[i]['statusClass'] = '';
                    if(status === 'open') $scope.orders[i]['statusClass'] = 'good';
                    if(status === 'cancelled') $scope.orders[i]['statusClass'] = 'bad';

                    var notes = $scope.orders[i]['notes'];
                    if(notes) {
                        notes = notes.split('\n');
                        var continuation = (notes.length > 1 || notes[0].length > 20)? '...' : '';
                        $scope.orders[i]['preview'] = notes[0].substr(0,20) + continuation;
                    }
                }
            }

            $scope.createNewOrder = function(){
                var d = new Date();
                var today = (d.getMonth()+1) + "/" + d.getDate() + "/" + d.getFullYear();

                var httpReq = {
                    data: {"orderDate":today},
                    url: 'server/order',
                    method: 'post'
                };

                $http(httpReq).then(function (res) {
                    $scope.loadDetail({orderId:res.data.id})
                }, ERRORHANDLER);
            };

            //INIT
            $scope.updateList();

        }
    });
