angular.module('orderDetail').component('orderDetail',
    {
        templateUrl: 'app/order/order-detail.template.html',
        controller: function ($routeParams, $http, $scope, $location, $mdDialog, $mdToast, $mdMedia) {
            var _this = this;
            _this.orderId = $routeParams['orderId'];

            function ERRORHANDLER(res){
                if(res.status==401) $location.url('login');
                else if(res.status==503) console.log(res.data);
                else console.log(res);
            }

            $scope.updateStatus = function(){
                $scope.statusClass = '';
                if($scope.order.status === 'open') $scope.statusClass = 'good';
                if($scope.order.status === 'cancelled') $scope.statusClass = 'bad';
            }

            $scope.loadOrder = loadOrder;

            $scope.fulfillmentDetail = function(fulfillment){
                $location.url('fulfillment/'+fulfillment.fulfillmentId);
            };

            $scope.editOrderItem = function(e){
                if(!e.productId) return console.log('Cant edit. Missing productId');
                orderItemDialog(e);
            };

            $scope.addOrderItem = function(product) {
                orderItemDialog();
            };

            $scope.createFulfillment = function(){
                var d = new Date();
                var today = (d.getMonth()+1) + "/" + d.getDate() + "/" + d.getFullYear();

                var data = {
                    orderId:$scope.order.orderId,
                    orderNumber:$scope.order.orderNumber,
                    createdDate:today
                };

                var httpReq = {
                    data: data,
                    url: 'server/fulfillment',
                    method: 'post'
                };

                $http(httpReq).then(function (res) {
                    $location.url('fulfillment/'+res.data.id);
                }, ERRORHANDLER);
            };

            $scope.deleteOrder = function(e){

                var confirm = $mdDialog.confirm()
                    .title('Are you sure you want to delete '+$scope.order.orderNumber+'?')
                    .ariaLabel('Delete Order')
                    .targetEvent(e)
                    .ok('Delete')
                    .cancel('Keep');
                //
                $mdDialog.show(confirm).then(function() {
                    $http({
                        method:'delete',
                        data:{"orderId":$scope.order.orderId},
                        url:'server/order'
                    }).then(function(res){
                        $location.url('orders');
                    }, ERRORHANDLER);
                });
            };

            $scope.saveForm = function(e){
                var order = $scope.order;

                if(order.orderId) {

                    getGrowerInfo();

                    var httpReq = {
                        data: order,
                        url: 'server/order',
                        method: 'put'
                    };

                    $http(httpReq).then(function (res) {
                        $mdToast.show(
                            $mdToast.simple()
                                .textContent('Saved')
                                .position('top right')
                                .hideDelay(3000)
                        );
                        loadOrder();
                    }, ERRORHANDLER);
                }else{
                    console.log('Missing fields',prder);
                }

            };

            function orderItemDialog(product) {
                var useFullScreen = ($mdMedia('sm') || $mdMedia('xs'))  && $scope.customFullscreen;
                $mdDialog.show({
                        locals:{
                            varieties:$scope.varieties,
                            locations:$scope.locations,
                            varietyNames:$scope.varietyNames,
                            orderId:$scope.order.orderId,
                            product:product
                        },
                        controller: DialogController,
                        templateUrl: 'app/order/order-detail-add-item.html',
                        clickOutsideToClose:true,
                        fullscreen: useFullScreen
                    })
                    .then(function(answer) {
                        $scope.status = 'You said the information was "' + answer + '".';
                    }, function() {
                        $scope.status = 'You cancelled the dialog.';
                    });
                $scope.$watch(function() {
                    return $mdMedia('xs') || $mdMedia('sm');
                }, function(wantsFullScreen) {
                    $scope.customFullscreen = (wantsFullScreen === true);
                });
            };

            function DialogController($scope, $http, $mdToast, $mdDialog, varieties, locations, varietyNames, orderId, product) {
                $scope.locations = locations;
                $scope.varieties = varieties;
                $scope.varietyNames = varietyNames;


                $scope.hide = function() {
                    $mdDialog.hide();
                };
                $scope.cancel = function() {
                    $mdDialog.cancel();
                };
                $scope.answer = function(answer) {
                    $mdDialog.hide(answer);
                };

                $scope.querySearchLocation = function(query){
                    var results = query ? $scope.locations.filter( createFilterFor(query) ) : $scope.locations;
                    //var results = $scope.locations;
                    return results;
                };
                $scope.querySearchVariety = function(query){
                    var results = query ? $scope.varietyNames.filter( createFilterFor(query) ) : $scope.varietyNames;
                    //var results = $scope.locations;
                    return results;
                };
                    function createFilterFor(query) {
                        var lowercaseQuery = angular.lowercase(query);
                        return function filterFn(str) {

                            return (str.toLowerCase().indexOf(lowercaseQuery) === 0);
                        };
                    }

                $scope.prefillNewItem = function(product){
                    var varietyName, locationName;
                    if(product){
                        varietyName = product.variety;
                        locationName = product.location;
                    }else {
                        varietyName = $scope.newItemVarietySearch;
                        locationName = $scope.newItemLocationSearch;
                    }

                    $scope.newItem.location = locationName;
                    $scope.newItem.variety = varietyName;

                    console.log($scope.varieties);
                    for(var i=0;i<$scope.varieties.length;i++){
                        if($scope.varieties[i].variety === varietyName && $scope.varieties[i].location === locationName){
                            var target = $scope.varieties[i];

                            $scope.newItem.plantsPerBox = target.plantsPerBox;
                            $scope.newItemLocationSearch = target.location;
                            $scope.newItemVarietySearch = target.variety;
                        }
                    }
                };

                $scope.deleteNewItem = function(e){
                    if($scope.newItem.productId==='new') return $scope.hide();


                    var confirm = $mdDialog.confirm()
                        .title('Are you sure you want to delete '+$scope.newItem.varietyName+'?')
                        .ariaLabel('Delete Product')
                        .targetEvent(e)
                        .ok('Delete')
                        .cancel('Keep');
                    //
                    $mdDialog.show(confirm).then(function() {
                        $http({
                            method:'delete',
                            data:{"productId":$scope.newItem.productId},
                            url:'server/orderproduct'
                        }).then(function(res){
                            loadOrder();
                        }, ERRORHANDLER);
                    });

                };
                //
                // $scope.limitVariety = function(){
                //     var NAME=0, LOC=1;
                //     var locationTarget = $scope.newLocation;
                //
                //     //$scope.varietyNames = [];
                //     for(var i=0;i<$scope.originalVarietyNames.length;i++){
                //         var varietyName = $scope.originalVarietyNames[i].split(' - ');
                //         if(varietyName[LOC] === locationTarget){
                //             $scope.varietyNames.push($scope.originalVarietyNames[i]);
                //         }
                //     }
                //
                //     console.log($scope.varietyNames);
                // };

                $scope.saveItem = function(){
                    var item = $scope.newItem;
                    item.orderId = orderId;

                    if(item.orderId && item.variety) {
                        var httpReq = {
                            data: item,
                            url: 'server/orderproduct',
                            method: (item.productId==='new')?'post':'put'
                        };

                        $http(httpReq).then(function (res) {
                            $mdToast.show(
                                $mdToast.simple()
                                    .textContent('Saved')
                                    .position('top right')
                                    .hideDelay(3000)
                            );
                            $scope.cancel();
                            loadOrder();
                        }, ERRORHANDLER);
                    }else{
                        console.log('Missing fields',item);
                    }
                };

                $scope.updateQuantity = function(changed){
                    var hasBox = ($scope.newItem.boxQuantity && !($scope.newItem.boxQuantity==="") && !isNaN($scope.newItem.boxQuantity));
                    var hasRate = ($scope.newItem.plantsPerBox && !($scope.newItem.plantsPerBox==="") && !isNaN($scope.newItem.plantsPerBox));
                    var hasPlant = ($scope.newItem.plantQuantity && !($scope.newItem.plantQuantity==="") && !isNaN($scope.newItem.plantQuantity));

                    if(changed==='box' && !hasBox) return 'cleared';
                    if(changed==='plant' && !hasPlant) return 'cleared';
                    if(changed==='rate' && !hasRate) return 'cleared';

                    var autofilled = ($scope.newItem.suggested)? $scope.newItem.suggested : '';
                    hasBox = !(autofilled==='box' || !hasBox);
                    hasRate = !(autofilled==='rate' || !hasRate);
                    hasPlant = !(autofilled==='plant' || !hasPlant);

                    console.log(hasBox, hasRate, hasPlant, autofilled);

                    if(changed!=='plant' && hasBox && hasRate && !hasPlant){
                        $scope.newItem.suggested = 'plant';
                        $scope.newItem.plantQuantity = Number($scope.newItem.plantsPerBox) * Number($scope.newItem.boxQuantity);
                    } else if(changed!=='box' && !hasBox && hasRate && hasPlant){
                        $scope.newItem.suggested = 'box';
                        var box = Number($scope.newItem.plantQuantity) / Number($scope.newItem.plantsPerBox);
                        $scope.newItem.boxQuantity  = (Math.round(box*100))/100;
                    } else if(changed!=='rate' && hasBox && !hasRate && hasPlant){
                        $scope.newItem.suggested = 'rate';
                        var rate = Number($scope.newItem.plantQuantity) / Number($scope.newItem.boxQuantity);
                        $scope.newItem.plantsPerBox = (Math.round(rate*100))/100;
                    } else{
                        $scope.newItem.suggested = '';
                    }
                };


                if(product){
                    $scope.newItem = product;
                    $scope.newItem.varietyName = product.variety + ' - ' + product.location;
                    $scope.product = product;
                    $scope.prefillNewItem(product);
                }else{
                    $scope.newItem = {productId:"new"};
                }
            }

            function getGrowerInfo(){
                console.log('started grower info');
                var order = $scope.order;
                if(order.growerId){
                    console.log('tried getting growerId' + order.growerId);
                    for(var i=0;i<$scope.growers.length;i++){
                        var grower = $scope.growers[i];
                        console.log(grower);
                        if(grower.growerId == order.growerId){
                            console.log(grower);
                            order.growerName = grower.name;
                        }
                    }
                }
            }

            function loadOrder(){
                getOrder(_this.orderId, function(order){
                    if(order) $scope.order = order;
                    $scope.statusClass = '';
                    if(order.status){
                        if(order.status === 'open') $scope.statusClass = 'good';
                        if(order.status === 'cancelled') $scope.statusClass = 'bad';
                    }

                    getFulfillments(function(fulfillments){
                        $scope.fulfillments = fulfillments;
                        console.log($scope.fulfillments)

                        getGrowers(function(growerList){
                            $scope.growers = growerList;

                            getVarieties(function(varietyList){
                                $scope.locations = varietyList.locations;
                                $scope.varieties = varietyList.varieties;
                                $scope.varietyNames= varietyList.varietyNames;
                            });
                        });
                    });
                });
            };

            function getOrder(id, callback){
                if(_this.orderId && _this.orderId !=='new') {
                    $http.get('server/order?orderId=' + id).then(function (res) {
                        callback(res.data);
                    }, ERRORHANDLER);
                }else{
                    callback();
                }
            }

            function getFulfillments(callback){
                if(_this.orderId && _this.orderId !=='new') {
                    $http.get('server/fulfillmentlistbyorder?orderId='+_this.orderId).then(function (response) {
                        var fulfillments = response.data;

                        for (var i = 0; i < fulfillments.length; i++) {
                            var notes = fulfillments[i]['notes'];
                            if (notes) {
                                notes = notes.split('\n');
                                var continuation = (notes.length > 1 || notes[0].length > 20) ? '...' : '';
                                fulfillments[i]['preview'] = notes[0].substr(0, 20) + continuation;
                            }
                        }

                        return callback(fulfillments);
                    });
                }
            }

            function getGrowers(callback){
                $http.get('server/growerlist').then(function (response) {
                    callback(response.data);
                }, ERRORHANDLER);
            }

            function getVarieties(callback){
                $http.get('server/productlist').then(function (response) {
                    var allVarieties = response.data;

                    //build list of products/locations
                    var locations = [];
                    var varietyNames = [];
                    for(var i=0;i<allVarieties.length;i++){
                        var loc = allVarieties[i].location.replace(' ','');
                        var name = allVarieties[i].variety.replace(' ','');

                        if(!locations[loc]) locations[loc] = allVarieties[i].location;
                        if(!varietyNames[name]) varietyNames[name] = allVarieties[i].variety;
                    }

                    var varietyData = {locations:[], varieties:response.data, varietyNames:[]};
                    for(var lkey in locations){
                        varietyData.locations.push(locations[lkey]);
                    }
                    for(var nkey in varietyNames){
                        varietyData.varietyNames.push(varietyNames[nkey]);
                    }

                    callback(varietyData);
                }, ERRORHANDLER);
            }
            //INIT
            $scope.loadOrder();
        }
    });
