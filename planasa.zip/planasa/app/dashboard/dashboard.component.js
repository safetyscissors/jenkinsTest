angular.module('dashboard').component('dashboard',
    {
        templateUrl: 'app/dashboard/dashboard.template.html',
        controller: function(){
        }
    });