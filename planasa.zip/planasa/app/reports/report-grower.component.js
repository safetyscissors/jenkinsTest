angular.module('reportGrower').component('reportGrower',
    {
        templateUrl: 'app/reports/report-grower.template.html',
        controller: function($routeParams, $http, $scope){
            var _this = this;
            _this.variety = 'Albion';
            _this.location = 'Macdoel';

            //set menu item
            INDEXPAGE.setSelectedNav('report-variety1');

            $scope.updateProrate = function(){
                var httpReq = {
                    data: {
                        prorate:$scope.prorate,
                        variety:_this.variety,
                        location:_this.location
                    },
                    url: 'server/prorate',
                    method: 'post'
                };
                $http(httpReq).then(function(res){
                    $scope.loadReport(_this.location, _this.variety);
                });

            };

            $scope.querySearchLocation = function(query){
                var results = query ? $scope.locations.filter( createFilterFor(query) ) : $scope.locations;
                //var results = $scope.locations;
                return results;
            };

            $scope.querySearchVariety = function(query){
                var results = query ? $scope.varieties.filter( createFilterFor(query) ) : $scope.varieties;
                //var results = $scope.locations;
                return results;
            };

                function createFilterFor(query) {
                    var lowercaseQuery = query.toLowerCase();
                    return function filterFn(str) {
                        return (str.toLowerCase().indexOf(lowercaseQuery) === 0);
                    };
                }

            $scope.newReport = function(){
                var location = $scope.newItemLocationSearch;
                var variety = $scope.newItemVarietySearch;

                if(!location || !variety) return false;
                $scope.loadReport(location, variety);
            };

            $scope.loadReport  = function(newLoc,newVar) {
                if(newLoc) _this.location = newLoc;
                if(newVar) _this.variety = newVar;
                $scope.myOrder = 'prDeliveredPc';
                $scope.varietyName = _this.variety;
                $scope.locationName = _this.location;


                $http.get('server/prorate?variety='+_this.variety+'&location='+_this.location).then(function(resProrate) {
                    if(resProrate.data.prorate){
                        $scope.prorate = resProrate.data.prorate;
                    }else{
                        $scope.prorate = 100;
                    }

                    $http.get('server/productlist').then(function (resProducts) {
                        var allVarieties = resProducts.data;
                        parseVarieties(allVarieties);

                        $http.get('server/dailygrower?variety=' + _this.variety + '&location=' + _this.location).then(function (response) {
                            var report = response.data;
                            var growers = [];

                            $scope.newItemLocationSearch = _this.location;
                            $scope.newItemVarietySearch = _this.variety;

                            for (var i = 0; i < report.orders.length; i++) {
                                var listItem = report.orders[i];
                                var grower = growers[listItem.growerId];
                                if (grower && grower.growerId) {
                                    grower.growerQuantity += Number(listItem.plantQuantity);
                                } else {
                                    grower = {
                                        growerId: listItem.growerId,
                                        growerQuantity: Number(listItem.plantQuantity) || 0,
                                        clubName: listItem.clubName,
                                        growerName: listItem.growerName,
                                        fulfillmentQuantity: 0
                                    }
                                }
                                growers[listItem.growerId] = grower;
                            }

                            for (var i = 0; i < report.fulfillments.length; i++) {
                                var listItem = report.fulfillments[i];
                                var grower = growers[listItem.growerId];
                                if(!grower) continue;
                                if (grower && grower.growerId) {
                                    grower.fulfillmentQuantity += Number(listItem.plantQuantity);
                                }
                                growers[listItem.growerId] = grower;
                            }

                            $scope.report = [];
                            for (var key in growers) {
                                $scope.report.push(growers[key]);
                            }

                            for (var j = 0; j < $scope.report.length; j++) {
                                var grower = $scope.report[j];
                                var prorate = 1;
                                if (Number($scope.prorate)) prorate = Number($scope.prorate) / 100;
                                var prorateQuantity = Math.ceil(prorate * Number(grower.growerQuantity));
                                $scope.report[j].prorateQuantity = prorateQuantity;
                                $scope.report[j].prDeliveredPc = Math.ceil((Number(grower.fulfillmentQuantity) / Number(prorateQuantity)) * 100);
                                $scope.report[j].prBalance = Math.ceil(Number(prorateQuantity) - Number(grower.fulfillmentQuantity));

                                var status = 'good';
                                if($scope.report[j].prDeliveredPc >=85) status = 'warn';
                                if($scope.report[j].prDeliveredPc >=100) status = 'bad';
                                $scope.report[j].status = status;

                                $scope.report[j].deliveredPc = Math.ceil((Number(grower.fulfillmentQuantity) / Number(grower.growerQuantity)) * 100);
                                $scope.report[j].balance = Math.ceil(Number(grower.growerQuantity) - Number(grower.fulfillmentQuantity));
                            }

                        });
                    });
                });
            };
            $scope.loadReport();

            function parseVarieties(varietyList){
                var locations = [];
                var varieties = [];
                for(key in varietyList){
                    var product = varietyList[key];
                    locations[product.location] = product.location;
                    varieties[product.variety] = product.variety;
                }

                $scope.locations = [];
                $scope.varieties = [];
                for(locKey in locations){
                    $scope.locations.push(locations[locKey]);
                }
                for(varKey in varieties){
                    $scope.varieties.push(varieties[varKey]);
                }
            }
        }
    });