angular.module('report').component('report',
    {
        templateUrl: 'app/reports/report.template.html',
        controller: function($routeParams, $http, $scope){
            var _this = this;
            _this.variety = 'Albion';
            _this.location = 'McArthur';

            $scope.varietyName = _this.variety;
            $scope.locationName = _this.location;

            $scope.updateProrate = function(){
                var httpReq = {
                    data: {
                        prorate:$scope.prorate,
                        variety:_this.variety,
                        location:_this.location
                    },
                    url: 'server/prorate',
                    method: 'post'
                };
                $http(httpReq).then(function(res){
                    $scope.loadReport(_this.location, _this.variety);
                });

            };

            $scope.querySearchLocation = function(query){
                var results = query ? $scope.locations.filter( createFilterFor(query) ) : $scope.locations;
                //var results = $scope.locations;
                return results;
            };

            $scope.querySearchVariety = function(query){
                var results = query ? $scope.varieties.filter( createFilterFor(query) ) : $scope.varieties;
                //var results = $scope.locations;
                return results;
            };

                function createFilterFor(query) {
                    var lowercaseQuery = query.toLowerCase();
                    return function filterFn(str) {
                        return (str.toLowerCase().indexOf(lowercaseQuery) === 0);
                    };
                }

            $scope.newReport = function(){
                var location = $scope.newItemLocationSearch;
                var variety = $scope.newItemVarietySearch;

                if(!location || !variety) return false;
                $scope.loadReport(location, variety);
            };

            $scope.loadReport  = function(newLoc,newVar) {
                if(newLoc) _this.location = newLoc;
                if(newVar) _this.variety = newVar;
                $scope.myOrder = 'prDeliveredPc';

                $http.get('server/prorate?variety='+_this.variety+'&location='+_this.location).then(function(resProrate) {
                    if(resProrate.data.prorate){
                        $scope.prorate = resProrate.data.prorate;
                    }else{
                        $scope.prorate = "";
                    }

                    $http.get('server/productlist').then(function (resProducts) {
                        var allVarieties = resProducts.data;
                        parseVarieties(allVarieties);

                        $http.get('server/daily?variety=' + _this.variety + '&location=' + _this.location).then(function (response) {
                            var report = response.data;
                            var orders = [];

                            $scope.newItemLocationSearch = _this.location;
                            $scope.newItemVarietySearch = _this.variety;

                            for (var i = 0; i < report.orders.length; i++) {
                                var listItem = report.orders[i];
                                var order = orders[listItem.orderId];
                                if (order && order.orderId) {
                                    order.orderQuantity += Number(listItem.plantQuantity);
                                } else {
                                    order = {
                                        orderId: listItem.orderId,
                                        orderNumber: listItem.orderNumber,
                                        orderQuantity: Number(listItem.plantQuantity) || 0,
                                        growerId: listItem.growerId,
                                        growerName: listItem.growerName,
                                        fulfillmentQuantity: 0
                                    }
                                }
                                orders[listItem.orderId] = order;
                            }

                            for (var i = 0; i < report.fulfillments.length; i++) {
                                var listItem = report.fulfillments[i];
                                var order = orders[listItem.orderId];
                                if(!order) continue;
                                if (order && order.orderId) {
                                    order.fulfillmentQuantity += Number(listItem.plantQuantity);
                                }
                                orders[listItem.orderId] = order;
                            }

                            $scope.report = [];
                            for (var key in orders) {
                                $scope.report.push(orders[key]);
                            }

                            var total = {
                                order:0,
                                orderProrated:0,
                                delivered:0,
                                balance:0,
                            };

                            for (var j = 0; j < $scope.report.length; j++) {
                                var order = $scope.report[j];
                                var prorate = 1;
                                if (Number($scope.prorate)) prorate = Number($scope.prorate) / 100;
                                var prorateQuantity = Math.ceil(prorate * Number(order.orderQuantity));
                                $scope.report[j].prorateQuantity = prorateQuantity;
                                $scope.report[j].prDeliveredPc = Math.ceil((Number(order.fulfillmentQuantity) / Number(prorateQuantity)) * 100);
                                $scope.report[j].prBalance = Math.ceil(Number(prorateQuantity) - Number(order.fulfillmentQuantity));

                                var status = 'good';
                                if($scope.report[j].prDeliveredPc >=85) status = 'warn';
                                if($scope.report[j].prDeliveredPc >=100) status = 'bad';
                                $scope.report[j].status = status;

                                $scope.report[j].deliveredPc = Math.ceil((Number(order.fulfillmentQuantity) / Number(order.orderQuantity)) * 100);
                                $scope.report[j].balance = Math.ceil(Number(order.orderQuantity) - Number(order.fulfillmentQuantity));

                                total.order += order.orderQuantity;
                                total.orderProrated += prorateQuantity;
                                total.delivered += order.fulfillmentQuantity;
                                total.balance += order.balance;
                            }

                            total.balanceProrated = Math.ceil(Number(total.orderProrated) - Number(total.delivered));
                            total.deliveredPc = Math.ceil((Number(total.delivered) / Number(total.order)) * 100);
                            total.prDeliveredPc = Math.ceil((Number(total.delivered) / Number(total.orderProrated)) * 100);
                            $scope.total = total;
                        });
                    });
                });
            };
            $scope.loadReport();

            function parseVarieties(varietyList){
                var locations = [];
                var varieties = [];
                for(key in varietyList){
                    var product = varietyList[key];
                    locations[product.location] = product.location;
                    varieties[product.variety] = product.variety;
                }

                $scope.locations = [];
                $scope.varieties = [];
                for(locKey in locations){
                    $scope.locations.push(locations[locKey]);
                }
                for(varKey in varieties){
                    $scope.varieties.push(varieties[varKey]);
                }
            }
        }
    });