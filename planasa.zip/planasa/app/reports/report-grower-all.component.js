angular.module('reportGrowerAll').component('reportGrowerAll',
    {
        templateUrl: 'app/reports/report-grower-all.template.html',
        controller: function($routeParams, $http, $scope){
            var _this = this;
            _this.growerName = '';
            $scope.growerName = _this.growerName;

            $scope.querySearchGrower = function(query){
                var results = query ? $scope.growers.filter( createFilterFor(query) ) : $scope.growers;
                return results;
            };

            function createFilterFor(query) {
                var lowercaseQuery = query.toLowerCase();
                return function filterFn(str) {
                    return (str.toLowerCase().indexOf(lowercaseQuery) === 0);
                };
            }

            $scope.newReport = function(){
                var grower = $scope.newItemGrowerSearch;
                if(!grower) return false;

                var growerId = getGrowerId(grower);
                $scope.loadReport(growerId);
            };

            $scope.loadReport  = function(newGrower) {
                _this.growerId = (newGrower)? newGrower : 1;
                _this.growerName = "";
                $scope.myOrder = 'prDeliveredPc';


                $http.get('server/growerlist').then(function (resGrower) {
                    var allGrowers = resGrower.data;
                    parseGrowers(allGrowers);
                    $scope.growerName = $scope.growerIds[_this.growerId].name;

                    $http.get('server/reportgrower?growerId=' + _this.growerId).then(function (response) {

                        var report = response.data;
                        var orders = [];

                        for (var i = 0; i < report.orders.length; i++) {
                            var listItem = report.orders[i];
                            var order = orders[listItem.orderId];
                            if (order && order.orderId) {
                                order.orderQuantity += Number(listItem.plantQuantity);
                            } else {
                                order = {
                                    orderId: listItem.orderId,
                                    orderNumber: listItem.orderNumber,
                                    variety:listItem.variety,
                                    location:listItem.location,
                                    prorate:listItem.prorate,
                                    orderQuantity: Number(listItem.plantQuantity) || 0,
                                    growerId: listItem.growerId,
                                    growerName: listItem.growerName,
                                    fulfillmentQuantity: 0
                                }
                            }
                            orders[listItem.orderId+listItem.location+listItem.variety] = order;
                        }

                        for (var i = 0; i < report.fulfillments.length; i++) {
                            var listItem = report.fulfillments[i];
                            var order = orders[listItem.orderId+listItem.location+listItem.variety];
                            if(!order) continue;
                            if (order && order.orderId) {
                                order.fulfillmentQuantity += Number(listItem.plantQuantity);
                            }
                            orders[listItem.orderId+listItem.location+listItem.variety] = order;
                        }

                        $scope.report = [];
                        for (var key in orders) {
                            $scope.report.push(orders[key]);
                        }

                        for (var j = 0; j < $scope.report.length; j++) {
                            var order = $scope.report[j];
                            var prorate = 1;
                            if (Number(order.prorate)) prorate = Number(order.prorate) / 100;
                            var prorateQuantity = Math.ceil(prorate * Number(order.orderQuantity));
                            $scope.report[j].prorateQuantity = prorateQuantity;
                            $scope.report[j].prDeliveredPc = Math.ceil((Number(order.fulfillmentQuantity) / Number(prorateQuantity)) * 100);
                            $scope.report[j].prBalance = Math.ceil(Number(prorateQuantity) - Number(order.fulfillmentQuantity));

                            var status = 'good';
                            if($scope.report[j].prDeliveredPc >=85) status = 'warn';
                            if($scope.report[j].prDeliveredPc >=100) status = 'bad';
                            $scope.report[j].status = status;

                            $scope.report[j].deliveredPc = Math.ceil((Number(order.fulfillmentQuantity) / Number(order.orderQuantity)) * 100);
                            $scope.report[j].balance = Math.ceil(Number(order.orderQuantity) - Number(order.fulfillmentQuantity));
                        }

                    });
                });
            };
            $scope.loadReport();

            function getGrowerId(growerName){
                for(var key in $scope.growerList){
                    if($scope.growerList[key].name.toLowerCase() === growerName.toLowerCase()){
                        return $scope.growerList[key].growerId;
                    }
                }
                return false;
            }

            function parseGrowers(growerList){
                $scope.growers = [];
                $scope.growerIds = [];
                $scope.growerList = growerList;
                for(var key in growerList){
                    var grower = growerList[key];
                    $scope.growerIds[grower.growerId] = grower;
                    $scope.growers.push(grower.name);
                }
            }
        }
    });