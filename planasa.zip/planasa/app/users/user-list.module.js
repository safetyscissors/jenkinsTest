angular.module('userList', []).config(function($mdThemingProvider){
    $mdThemingProvider.theme('docs-dark', 'default')
        .primaryPalette('yellow')
        .dark();
});
