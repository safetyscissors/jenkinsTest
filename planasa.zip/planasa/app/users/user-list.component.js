
angular.module('userList').component('userList',
    {
        templateUrl: 'app/users/user-list.template.html',
        controller: function($routeParams, $http, $scope, $location, $mdDialog, $mdToast){
            var _this = this;
            _this.clientId = $routeParams['clientId'];

            //set menu item
            INDEXPAGE.setSelectedNav('users');

            function ERRORHANDLER(res){
                if(res.status==401) $location.url('login');
                else if(res.status==503) console.log(res.data);
                else console.log(res);
            }

            $scope.addNewUser = function(){
                $scope.setUser({userId:'new'})
            };

            $scope.showConfirm = function(e){
                var confirm = $mdDialog.confirm()
                    .title('Are you sure you want to delete '+$scope.selected.name+'?')
                    .ariaLabel('Delete User')
                    .targetEvent(e)
                    .ok('Delete')
                    .cancel('Keep');

                $mdDialog.show(confirm).then(function() {
                    var data = $scope.selected;
                    var previous = 'new';
                    for (var i = 0; i < $scope.userList.length; i++) {
                        if ($scope.userList[i].userId == data.userId) {
                            $scope.selected = $scope.userList[previous];
                        }else{
                            previous = i;
                        }
                    }

                    $http({
                        method:'delete',
                        data:data,
                        url:'server/user'
                    }).then(function(res){
                        $scope.updateUsersList();
                    }, ERRORHANDLER);
                });
            };

            $scope.saveForm = function(e){
                if(!e.userId) return console.log('No clientId');

                var dataCopy = angular.copy(e);
                var httpReq = {
                    "data": dataCopy,
                    "url": "server/user",
                    "method": "put"
                };

                dataCopy.permissions = [
                    dataCopy.permissionList.user,
                    dataCopy.permissionList.grower,
                    dataCopy.permissionList.product
                ];
                dataCopy.permissions = dataCopy.permissions.filter(function(n){ return n != '' });
                dataCopy.permissions = dataCopy.permissions.join(',');


                if(dataCopy.userId === 'new') httpReq.method = 'post';

                $http(httpReq).then(function(res){
                    $mdToast.show(
                        $mdToast.simple()
                            .textContent('Saved')
                            .position('top right')
                            .hideDelay(3000)
                    );
                    $scope.updateUsersList(e.userId==='new');
                }, ERRORHANDLER);
            };

            $scope.setUser = function(e){
                if(!e.userId) return console.log('No UserId');
                if(e.userId==='new') return $scope.selected = e;

                $http.get('server/user?userid='+e.userId).then(function(res){
                    var user = res.data[0];

                    user.permissionList = { user:'', grower:'', product:'' };
                    var userPermissions = user.permissions.split(',');
                    for(var index in userPermissions){
                        var permission = userPermissions[index];
                        if(permission === 'user' || permission === 'userEdit') user.permissionList.user = permission;
                        if(permission === 'grower' || permission === 'growerEdit') user.permissionList.grower = permission;
                        if(permission === 'product' || permission === 'productEdit') user.permissionList.product = permission;
                    }

                    $scope.selected = user;
                }, ERRORHANDLER);
            };

            $scope.updateUsersList = function(isNew){
                $http.get('server/userlist').then(function(res){
                    $scope.userList = res.data;

                    if(isNew){
                        $scope.setUser($scope.userList[$scope.userList.length - 1]);
                    }
                    else if($scope.selected){
                        $scope.setUser($scope.selected);
                    }
                    else if(_this.userId){
                        for(var i=0;i<s$scope.userList.length;i++){
                            if($scope.userList[i].userId == _this.userId){
                                $scope.setUser($scope.userList[i]);
                            }
                        }
                    }
                    else{
                        $scope.setUser($scope.userList[0]);
                    }
                }, ERRORHANDLER);
            };

            //ON INIT
            $scope.updateUsersList();
        }
    });