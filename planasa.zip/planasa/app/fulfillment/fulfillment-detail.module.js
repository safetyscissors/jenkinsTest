angular.module('fulfillmentDetail', []);
