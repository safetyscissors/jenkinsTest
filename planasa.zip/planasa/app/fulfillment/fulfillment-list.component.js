angular.module('fulfillmentList').component('fulfillmentList',
    {
        templateUrl: 'app/fulfillment/fulfillment-list.template.html',
        controller: function($routeParams, $http, $scope, $location){
            var _this = this;

            function ERRORHANDLER(res) {
                if (res.status == 401) $location.url('login');
                else if (res.status == 503) console.log(res.data);
                else console.log(res);
            }

            $scope.detail = function(fulfillment){
                $location.url('fulfillment/'+fulfillment.fulfillmentId);
            };

            $scope.searchList = function(){
                if(!$scope.searchText) $scope.searchText = "";
                var search ='?status='+$scope.searchStatus+'&search='+$scope.searchText;
                $http.get('server/fulfillmentsearch'+search).then(loadList, ERRORHANDLER);

            };

            $scope.bigSearch = function(){
                $scope.searchSizeClass = "big";
            };
            $scope.smallSearch = function(){
                if($scope.searchText && $scope.searchText.length>0) return;
                $scope.searchSizeClass = "small";
            };

            $scope.updateList = function(){
                if($routeParams['query']){
                    console.log('querying:',$routeParams['query']);
                    $scope.searchText = $routeParams['query'];
                    $scope.searchStatus = 'all';
                    $scope.searchList();
                }else {
                    $http.get('server/fulfillmentlist').then(loadList, ERRORHANDLER);
                }
            }
            $scope.updateList();

            function loadList(response){
                _this.fulfillments = response.data;
                if(!$scope.searchStatus) $scope.searchStatus = "all";

                for(var i=0;i<_this.fulfillments.length;i++){
                    var status = _this.fulfillments[i]['status'];
                    _this.fulfillments[i]['statusClass'] = '';
                    if(status === 'open') _this.fulfillments[i]['statusClass'] = 'good';
                    if(status === 'cancelled') _this.fulfillments[i]['statusClass'] = 'bad';

                    var notes = _this.fulfillments[i]['notes'];
                    if(notes) {
                        notes = notes.split('\n');
                        var continuation = (notes.length > 1 || notes[0].length > 20)? '...' : '';
                        _this.fulfillments[i]['preview'] = notes[0].substr(0,20) + continuation;
                    }
                }
            }

        }
    });
