angular.module('fulfillmentDetail').component('fulfillmentDetail',
    {
        templateUrl: 'app/fulfillment/fulfillment-detail.template.html',
        controller: function ($routeParams, $window, $http, $scope, $location, $mdDialog, $mdToast, $mdMedia) {
            var _this = this;
            _this.fulfillmentId = $routeParams['fulfillmentId'];
            //set menu item
            INDEXPAGE.setSelectedNav('fulfill');

            function ERRORHANDLER(res) {
                if (res.status == 401) $location.url('login');
                else if (res.status == 503) console.log(res.data);
                else console.log(res);
            }
            $scope.updateStatus = function(){
                $scope.statusClass = '';
                if($scope.fulfillment.status){
                    if($scope.fulfillment.status === 'open') $scope.statusClass = 'good';
                    if($scope.fulfillment.status === 'cancelled') $scope.statusClass = 'bad';
                }
            };

            $scope.makeInvoice = function(){
                $window.open("app/invoice.php?id="+_this.fulfillmentId, "_blank")
            };

            $scope.loadFulfillment = loadFulfillment;

            $scope.orderDetail = function(orderId){
                $location.url('orders/'+orderId);
            };

            $scope.deleteFulfillment= function(e){
                var confirm = $mdDialog.confirm()
                    .title('Are you sure you want to delete this fulfillment for '+$scope.fulfillment.orderNumber+'?')
                    .ariaLabel('Delete Fulfillment')
                    .targetEvent(e)
                    .ok('Delete')
                    .cancel('Keep');
                //
                $mdDialog.show(confirm).then(function() {
                    $http({
                        method:'delete',
                        data:{"fulfillmentId":$scope.fulfillment.fulfillmentId},
                        url:'server/fulfillment'
                    }).then(function(res){
                        $location.url('fulfillment');
                    }, ERRORHANDLER);
                });
            };

            $scope.saveForm = function(e){
                var fulfillment = $scope.fulfillment;

                if(fulfillment.fulfillmentId) {

                    var httpReq = {
                        data: fulfillment,
                        url: 'server/fulfillment',
                        method: 'put'
                    };

                    $http(httpReq).then(function (res) {
                        $mdToast.show(
                            $mdToast.simple()
                                .textContent('Saved')
                                .position('top right')
                                .hideDelay(3000)
                        );
                        loadFulfillment();
                    }, ERRORHANDLER);
                }else{
                    console.log('Missing fields',fulfillment);
                }

            };


            $scope.editFulfillmentItem = function(e){
                if(!e.fulfillmentItemId) return console.log('Cant edit. Missing fulfillmentId');
                console.log(e);
                fulfillmentItemDialog(e);
            };

            $scope.fulfillmentItemDialog = fulfillmentItemDialog;

            function fulfillmentItemDialog(product) {
                var useFullScreen = ($mdMedia('sm') || $mdMedia('xs'))  && $scope.customFullscreen;
                $mdDialog.show({
                        locals:{
                            fulfillmentId:$scope.fulfillment.fulfillmentId,
                            product:product,
                            varietyList:$scope.varietyList
                        },
                        controller: DialogController,
                        templateUrl: 'app/fulfillment/fulfillment-detail-add-item.html',
                        clickOutsideToClose:true,
                        fullscreen: useFullScreen
                    })
                    .then(function(answer) {
                        $scope.status = 'You said the information was "' + answer + '".';
                    }, function() {
                        $scope.status = 'You cancelled the dialog.';
                    });
                $scope.$watch(function() {
                    return $mdMedia('xs') || $mdMedia('sm');
                }, function(wantsFullScreen) {
                    $scope.customFullscreen = (wantsFullScreen === true);
                });
            };

            function DialogController($scope, $http, $mdToast, $mdDialog, fulfillmentId, product, varietyList) {
                $scope.locations = varietyList.locations;
                $scope.varieties = varietyList.varieties;
                $scope.varietyNames = varietyList.varietyNames;


                $scope.hide = function() {
                    $mdDialog.hide();
                };
                $scope.cancel = function() {
                    $mdDialog.cancel();
                };

                $scope.querySearchLocation = function(query){
                    var results = query ? $scope.locations.filter( createFilterFor(query) ) : $scope.locations;
                    //var results = $scope.locations;
                    return results;
                };
                $scope.querySearchVariety = function(query){
                    var results = query ? $scope.varietyNames.filter( createFilterFor(query) ) : $scope.varietyNames;
                    //var results = $scope.locations;
                    return results;
                };
                    function createFilterFor(query) {
                        var lowercaseQuery = angular.lowercase(query);
                        return function filterFn(str) {

                            return (str.toLowerCase().indexOf(lowercaseQuery) === 0);
                        };
                    }


                $scope.prefillNewItem = function(product){
                    var varietyName, locationName;
                    if(product){
                        varietyName = product.variety;
                        locationName = product.location;
                    }else {
                        varietyName = $scope.newItemVarietySearch;
                        locationName = $scope.newItemLocationSearch;
                    }

                    $scope.newItem.location = locationName;
                    $scope.newItem.variety = varietyName;

                    for(var i=0;i<$scope.varieties.length;i++){
                        if($scope.varieties[i].variety === varietyName && $scope.varieties[i].location === locationName){
                            var target = $scope.varieties[i];

                            $scope.newItem.plantsPerBox = target.plantsPerBox;
                            $scope.newItemLocationSearch = target.location;
                            $scope.newItemVarietySearch = target.variety;
                        }
                    }
                };

                $scope.deleteNewItem = function(e){
                    return $scope.hide();
                    //not done
                };

                $scope.saveItem = function(){
                    var item = $scope.newItem;
                    item.fulfillmentId = fulfillmentId;

                    if(item.fulfillmentItemId && item.variety) {
                        var httpReq = {
                            data: item,
                            url: 'server/fulfillmentItem',
                            method: (item.fulfillmentItemId==='new')?'post':'put'
                        };

                        $http(httpReq).then(function (res) {
                            $mdToast.show(
                                $mdToast.simple()
                                    .textContent('Saved')
                                    .position('top right')
                                    .hideDelay(3000)
                            );
                            $scope.cancel();
                            loadFulfillment();
                        }, ERRORHANDLER);
                    }else{
                        console.log('Missing fields',item);
                    }
                };

                $scope.updateQuantity = function(changed){
                    var hasBox = ($scope.newItem.boxQuantity && !($scope.newItem.boxQuantity==="") && !isNaN($scope.newItem.boxQuantity));
                    var hasRate = ($scope.newItem.plantsPerBox && !($scope.newItem.plantsPerBox==="") && !isNaN($scope.newItem.plantsPerBox));
                    var hasPlant = ($scope.newItem.plantQuantity && !($scope.newItem.plantQuantity==="") && !isNaN($scope.newItem.plantQuantity));

                    if(changed==='box' && !hasBox) return 'cleared';
                    if(changed==='plant' && !hasPlant) return 'cleared';
                    if(changed==='rate' && !hasRate) return 'cleared';

                    var autofilled = ($scope.newItem.suggested)? $scope.newItem.suggested : '';
                    hasBox = !(autofilled==='box' || !hasBox);
                    hasRate = !(autofilled==='rate' || !hasRate);
                    hasPlant = !(autofilled==='plant' || !hasPlant);

                    console.log(hasBox, hasRate, hasPlant, autofilled);

                    if(changed!=='plant' && hasBox && hasRate && !hasPlant){
                        $scope.newItem.suggested = 'plant';
                        $scope.newItem.plantQuantity = Number($scope.newItem.plantsPerBox) * Number($scope.newItem.boxQuantity);
                    } else if(changed!=='box' && !hasBox && hasRate && hasPlant){
                        $scope.newItem.suggested = 'box';
                        var box = Number($scope.newItem.plantQuantity) / Number($scope.newItem.plantsPerBox);
                        $scope.newItem.boxQuantity  = (Math.round(box*100))/100;
                    } else if(changed!=='rate' && hasBox && !hasRate && hasPlant){
                        $scope.newItem.suggested = 'rate';
                        var rate = Number($scope.newItem.plantQuantity) / Number($scope.newItem.boxQuantity);
                        $scope.newItem.plantsPerBox = (Math.round(rate*100))/100;
                    } else{
                        $scope.newItem.suggested = '';
                    }
                };

                function init(){
                    if(product){
                        $scope.newItem = product;
                        $scope.product = product;
                        $scope.prefillNewItem(product);
                    }else{
                        var d = new Date();
                        var today = (d.getMonth()+1) + "/" + d.getDate() + "/" + d.getFullYear();
                        $scope.newItem = {fulfillmentItemId:"new", pickDate:today};
                    }
                } init();
            }


            function loadFulfillment(){
                if(_this.fulfillmentId && _this.fulfillmentId !=='new') {
                    $http.get('server/fulfillment?fulfillmentId=' + _this.fulfillmentId).then(function (res) {
                        $scope.fulfillment = res.data;

                        $scope.statusClass = '';
                        if($scope.fulfillment.status){
                            if($scope.fulfillment.status === 'open') $scope.statusClass = 'good';
                            if($scope.fulfillment.status === 'cancelled') $scope.statusClass = 'bad';
                        }

                        getVarieties(function(varietyList){
                            $scope.varietyList = varietyList;
                        });
                    }, ERRORHANDLER);
                }else{
                    console.log('missing fulfillmentId', _this.fulfillmentId);
                }
            };

            function getVarieties(callback){
                $http.get('server/productlist').then(function (response) {
                    var allVarieties = response.data;

                    //build list of products/locations
                    var locations = [];
                    var varietyNames = [];
                    for(var i=0;i<allVarieties.length;i++){
                        var loc = allVarieties[i].location.replace(' ','');
                        var name = allVarieties[i].variety.replace(' ','');

                        if(!locations[loc]) locations[loc] = allVarieties[i].location;
                        if(!varietyNames[name]) varietyNames[name] = allVarieties[i].variety;
                    }

                    var varietyData = {locations:[], varieties:response.data, varietyNames:[]};
                    for(var lkey in locations){
                        varietyData.locations.push(locations[lkey]);
                    }
                    for(var nkey in varietyNames){
                        varietyData.varietyNames.push(varietyNames[nkey]);
                    }

                    callback(varietyData);
                }, ERRORHANDLER);
            }

            //INIT
            $scope.loadFulfillment();
        }
    });