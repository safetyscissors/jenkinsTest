
angular.module('clientList').component('clientList',
    {
        templateUrl: 'app/client/client-list.template.html',
        controller: function($routeParams, $http, $scope, $location, $mdDialog, $mdToast){
            var _this = this;
            _this.clientId = $routeParams['clientId'];

            function ERRORHANDLER(res){
                if(res.status==401) $location.url('login');
                else if(res.status==503) console.log(res.data);
                else console.log(res);
            }

            $scope.addNewGrower = function(){
                $scope.setSelected({growerId:'new'})
            };

            $scope.addAddress = function(newAddress){
                if(!$scope.selected.addresses || $scope.selected.addresses === '') $scope.selected.addresses = [];
                if(! typeof $scope.selected.addresses === 'Array') $scope.selected.addresses = JSON.parse($scope.selected.addresses);
                $scope.selected.addresses.push(newAddress);
                $scope.selected.newAddress = '';
            };

            $scope.showConfirm = function(e){
                var confirm = $mdDialog.confirm()
                    .title('Are you sure you want to delete '+$scope.selected.name+'?')
                    .ariaLabel('Delete Grower')
                    .targetEvent(e)
                    .ok('Delete')
                    .cancel('Keep');

                $mdDialog.show(confirm).then(function() {
                    var data = $scope.selected;
                    var previous = 'new';
                    for (var i = 0; i < _this.clients.length; i++) {
                        if (_this.clients[i].growerId == data.growerId) {
                            $scope.selected = _this.clients[previous];
                        }else{
                            previous = i;
                        }
                    }

                    $http({
                        method:'delete',
                        data:data,
                        url:'server/grower'
                    }).then(function(res){
                        $scope.updateList();
                    }, ERRORHANDLER);
                });
            };

            $scope.setSelected = function(e){
                if(!e.growerId) return console.log('No growerId');

                //$location.path('grower/'+e.growerId, false);
                if(e.growerId === 'new') return $scope.selected = e;

                $http.get('server/grower?growerId='+e.growerId).then(function(res){
                    var grower = res.data[0];
                    if(!grower.addresses || !grower.addresses.match(/^\[.*\]$/g)){
                        grower.addresses = [];
                    } else{
                        grower.addresses = JSON.parse(grower.addresses);
                    }
                    $scope.selected = grower;

                }, ERRORHANDLER);

                //angular.element( document.querySelector(divId)).addClass('selected');
            };

            $scope.saveForm = function(e){
                if(!e.growerId) return console.log('No growerId');
                $scope.addAddress(e.newAddress);

                //loop through addresses, remove blank ones
                e.addresses = e.addresses.filter(function(n){ return (n != undefined && n !== "" && n != null) });

                var dataCopy = angular.copy(e);
                dataCopy.addresses = JSON.stringify(dataCopy.addresses);

                var httpReq = {
                    data:dataCopy,
                    url:'server/grower',
                    method:'put'
                };

                if(e.growerId==='new') httpReq.method = 'post';

                $http(httpReq).then(function(res){
                    $mdToast.show(
                        $mdToast.simple()
                            .textContent('Saved')
                            .position('top right')
                            .hideDelay(3000)
                    );
                    $scope.updateList(e.growerId==='new');
                }, ERRORHANDLER);
            };

            $scope.updateList = function(isNew) {
                $http.get('server/growerlist').then(function (response) {
                    _this.clients = response.data;

                    if(isNew) {
                        $scope.setSelected(_this.clients[_this.clients.length - 1]);
                    }
                    else if($scope.selected){
                        $scope.setSelected($scope.selected);
                    }
                    else if(_this.clientId){
                        for (var i = 0; i < _this.clients.length; i++) {
                            if (_this.clients[i].growerId == _this.clientId) {
                                $scope.setSelected(_this.clients[i]);
                            }
                        }
                    }
                    else{
                        $scope.setSelected(_this.clients[0]);
                    }

                }, ERRORHANDLER);
            }


            //ON INIT
            $scope.updateList();
        }
    });