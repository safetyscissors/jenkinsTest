<?php
  //create connection
  $configDB = new mysqli('localhost','root','password','planasa');

  //check connection
  if($configDB->connect_error){
    die('db connection failed:'.$configDB->connect_error);
  }
  return $configDB;
?>
