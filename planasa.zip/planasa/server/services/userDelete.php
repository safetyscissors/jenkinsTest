<?php
  require('authCheck.php');
  if(!isset($USER->id)) return;
  require('queries/userQueries.php');
  $PAGE->id='userDelete';

  $inputs=array();
  $_DELETE = json_decode(file_get_contents("php://input"));

  if(isset($_DELETE->userId) && !empty($_DELETE->userId)){
    $inputs['userId'] = $_DELETE->userId;
  }else{
    return errorHandler("userId is required", 503);
  }

  //setup for query
  $stmt = deleteUser($DB, $inputs['userId']);
  if(!$stmt) return; // getLists already send error.
  if(!$stmt->execute()) return errorHandler("failed to delete this list $stmt->errno: $stmt->error", 503);

  if($stmt->affected_rows != 1){
    return errorHandler("Deleted $stmt->affected_rows rows", 503);
  }

?>