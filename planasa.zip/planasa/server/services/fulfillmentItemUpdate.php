<?php
require('authCheck.php');
require('authPermissions.php');

if(!isset($USER->id)) return;
//if(!authPermissionCheck($USER,'product')) return;

require('queries/fulfillmentQueries.php');
$PAGE->id='orderUpdate';

$fields = array('fulfillmentItemId','fulfillmentId','productId','pickDate','variety','location','plantsPerBox','boxQuantity','plantQuantity','field','cooler','shed','truck','palletsIn','palletsOut');
$requiredFields = array('fulfillmentItemId','fulfillmentId','variety');
$inputs=array();
$put = json_decode(file_get_contents("php://input"));

//check input object for variables from front end
foreach($fields as $key=>$field){
    if(isset($put->{$field}) && !empty($put->{$field})){
        $inputs[$field] = $put->{$field};
    }else{
        $inputs[$field] = "";
    }
}

//check inputs for all required fields
foreach($requiredFields as $postKey){
    if(!isset($inputs[$postKey]) || empty($inputs[$postKey]) || $inputs[$postKey]==""){
        return errorHandler("missing $postKey", 503);
    }
}

//print debug statement
if($SERVERDEBUG){
    echo "\r\n inputs:";
    echo json_encode($inputs);
}

//setup for query
$stmt = updateFulfillmentItem($DB,$inputs['fulfillmentItemId'],$inputs['fulfillmentId'],$inputs['productId'],$inputs['pickDate'],$inputs['variety'],$inputs['location'],$inputs['plantsPerBox'],$inputs['boxQuantity'],$inputs['plantQuantity'],$inputs['field'],$inputs['cooler'],$inputs['shed'],$inputs['truck'],$inputs['palletsIn'],$inputs['palletsOut']);
if(!$stmt) return; // createNewList already send error.
if(!$stmt->execute()) return errorHandler("failed to update this sub order $stmt->errno: $stmt->error");
if($stmt->affected_rows != 1) return errorHandler("Updated $stmt->affected_rows rows", 503);
$stmt->close();

echo json_encode($inputs);
?>