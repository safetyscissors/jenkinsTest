<?php
  require('authCheck.php');
  require('authPermissions.php');

  if(!isset($USER->id)) return;
  if(!authPermissionCheck($USER,'growers')) return;

  require('queries/growerQueries.php');
  $PAGE->id='growerUpdate';
  $fields = array('growerId','name','county','countyShort','clubName','addresses','contact','phone','fax','email','notes');
  $requiredFields=array('growerId','name');
  $inputs=array();
  $put = json_decode(file_get_contents("php://input"));

  //check POST object for variables from front end
  foreach($fields as $key=>$field){
    if(isset($put->{$field}) && !empty($put->{$field})){
      $inputs[$field] = $put->{$field};
    }else{
      $inputs[$field] = "";
    }
  }

//  if(isset($inputs['addresses']) && !empty($inputs['addresses']))

  //check inputs for all required fields 
  foreach($requiredFields as $postKey){
    if(!isset($inputs[$postKey]) || empty($inputs[$postKey]) || $inputs[$postKey]==""){
      return errorHandler("missing $postKey", 503);
    }
  }

  //print debug statement
  if($SERVERDEBUG){
    echo "\r\n inputs:";
    echo json_encode($inputs);
  }

  //setup for query
  $stmt = updateGrower($DB, $inputs['growerId'],$inputs['name'],$inputs['county'],$inputs['countyShort'],$inputs['clubName'],$inputs['addresses'],$inputs['contact'],$inputs['phone'],$inputs['fax'],$inputs['email'],$inputs['notes']);
  if(!$stmt) return; // createNewList already send error.
  if(!$stmt->execute()) return errorHandler("failed to create this list $stmt->errno: $stmt->error");

  if($stmt->affected_rows != 1){
    return errorHandler("Updated $stmt->affected_rows rows", 503);
  }
  echo json_encode($inputs);
?>  