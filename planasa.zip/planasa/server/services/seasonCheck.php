<?php
    $SEASON="2016";
    return $SEASON;
?>