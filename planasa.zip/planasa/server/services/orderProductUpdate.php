<?php
require('authCheck.php');
require('authPermissions.php');

if(!isset($USER->id)) return;
//if(!authPermissionCheck($USER,'product')) return;

require('queries/orderQueries.php');
$PAGE->id='orderUpdate';

$fields = array('productId','variety','location','boxQuantity','plantsPerBox','plantQuantity');
$requiredFields = array('productId','variety','plantQuantity');
$inputs=array();
$put = json_decode(file_get_contents("php://input"));

//check input object for variables from front end
foreach($fields as $key=>$field){
    if(isset($put->{$field}) && !empty($put->{$field})){
        $inputs[$field] = $put->{$field};
    }else{
        $inputs[$field] = "";
    }
}

//check inputs for all required fields
foreach($requiredFields as $postKey){
    if(!isset($inputs[$postKey]) || empty($inputs[$postKey]) || $inputs[$postKey]==""){
        return errorHandler("missing $postKey", 503);
    }
}

//print debug statement
if($SERVERDEBUG){
    echo "\r\n inputs:";
    echo json_encode($inputs);
}

//setup for query
$stmt = updateOrderProduct($DB,$inputs['productId'],$inputs['variety'],$inputs['location'],$inputs['boxQuantity'],$inputs['plantsPerBox'],$inputs['plantQuantity']);
if(!$stmt) return; // createNewList already send error.
if(!$stmt->execute()) return errorHandler("failed to update this sub order $stmt->errno: $stmt->error");
if($stmt->affected_rows != 1) return errorHandler("Updated $stmt->affected_rows rows", 503);
$stmt->close();

echo json_encode($inputs);
?>