<?php
require('authCheck.php');
if(!isset($USER->id)) return;
require('queries/fulfillmentQueries.php');
$PAGE->id='fulfillmentDelete';

$inputs=array();
$_DELETE = json_decode(file_get_contents("php://input"));

if(isset($_DELETE->fulfillmentId) && !empty($_DELETE->fulfillmentId)){
    $inputs['fulfillmentId'] = $_DELETE->fulfillmentId;
}else{
    return errorHandler("fulfillmentId is required", 503);
}

//delete all sub order lines
$ordersStmt = deleteAllFulfillmentsById($DB, $inputs['fulfillmentId']);
if(!$ordersStmt) return; // getLists already send error.
if(!$ordersStmt->execute()) return errorHandler("failed to delete all sub fulfillments $ordersStmt->errno: $ordersStmt->error", 503);
$ordersStmt->close();

//delete the order
$stmt = deleteFulfillments($DB, $inputs['fulfillmentId']);
if(!$stmt) return; // getLists already send error.
if(!$stmt->execute()) return errorHandler("failed to delete this fulfillment $stmt->errno: $stmt->error", 503);
if($stmt->affected_rows != 1) return errorHandler("Deleted $stmt->affected_rows rows", 503);
$stmt->close();

?>