<?php
  require('authCheck.php');
  $PAGE->id='mainly';
?>