<?php
require('authCheck.php');
if(!isset($USER->id)) return;
require('queries/productQueries.php');
$PAGE->id='productDelete';

$inputs=array();
$_DELETE = json_decode(file_get_contents("php://input"));

if(isset($_DELETE->productId) && !empty($_DELETE->productId)){
    $inputs['productId'] = $_DELETE->productId;
}else{
    return errorHandler("ProductId is required", 503);
}

//setup for query
$stmt = deleteProduct($DB, $inputs['productId']);
if(!$stmt) return; // getLists already send error.
if(!$stmt->execute()) return errorHandler("failed to delete this product $stmt->errno: $stmt->error", 503);

if($stmt->affected_rows != 1){
    return errorHandler("Deleted $stmt->affected_rows rows", 503);
}

?>