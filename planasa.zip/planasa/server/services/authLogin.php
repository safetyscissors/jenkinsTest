<?php
	require('queries/userQueries.php');
	require('password_compat.php');
	$fields=array('email','password');
	$inputs=array();
$body = json_decode(file_get_contents("php://input"));

//check POST object for variables from front end
foreach($fields as $key=>$field){
	if(isset($body->{$field}) && !empty($body->{$field})){
		$inputs[$field] = $body->{$field};
	}else{
		$inputs[$field] = "";
	}
}

	//get the user's password
	$stmt = getUserByEmail($DB, $inputs['email']);
	if(!$stmt) return; //authLogin already sent an error.
  if(!$stmt->execute()) return errorHandler("failed to create this list $stmt->errno: $stmt->error");
  $data = array();
  $stmt->bind_result($data['id'],$data['name'],$data['hash'], $data['permissions']);
  $stmt->fetch();

  if(password_verify($inputs['password'], $data['hash'])){
  	$_SESSION['time'] = time();
  	$_SESSION['userId'] = $data['id'];
  	$_SESSION['name'] = $data['name'];
    $_SESSION['permissions'] = $data['permissions'];
  }else{
  	return errorHandler("password failed",503);
  }
?>
