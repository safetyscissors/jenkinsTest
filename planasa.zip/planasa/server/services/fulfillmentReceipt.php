<?php
require('../server/queries/fulfillmentQueries.php');
$DB = require('../server/dbConfig.php');

//get inputs. requires id
if(isset($_GET['id']) && !empty($_GET['id'])){
    $input=$_GET['id'];
}else{
    return;
}

//setup for query
$stmt = getFulfillment($DB, $input);
if(!$stmt) return; // stmt already send error.
if(!$stmt->execute()) return;
//format results
$data = array();
$stmt->bind_result(
    $data['fulfillmentId'],
    $data['fulfillmentNumber'],
    $data['orderId'],
    $data['orderNumber'],
    $data['orderDate'],
    $data['createdDate'],
    $data['deliveredDate'],
    $data['season'],
    $data['notes'],
    $data['status'],
    $data['fulfillmentItemId'],
    $data['pickDate'],
    $data['variety'],
    $data['location'],
    $data['plantsPerBox'],
    $data['boxQuantity'],
    $data['plantQuantity'],
    $data['field'],
    $data['shed'],
    $data['cooler'],
    $data['truck'],
    $data['palletsIn'],
    $data['palletsOut'],
    $data['growerName']


);

/* fetch values */
$res;
while($stmt->fetch()){
    if(!isset($res['fulfillmentId']) || empty($res['fulfillmentId'])){
        $res = $data;
        $res['fulfillments']= array();
    }

    $fulfillmentItemFields = array('fulfillmentItemId','pickDate','variety','location','plantsPerBox','boxQuantity','plantQuantity','field','shed','cooler','truck','palletsIn','palletsOut');
    if(isset($data['fulfillmentItemId']) && !empty($data['fulfillmentItemId'])) {
        array_push($res['fulfillments'], fillObj($data, $fulfillmentItemFields));
    }
}
$stmt->close();

return $res;

function fillObj($data, $keys){
    $result = array();
    foreach($keys as $index=>$key){
        $result[$key] = $data[$key];
    }
    return $result;
}
function arrayCopy( array $array ) {
    $result = array();
    foreach( $array as $key => $val ) {
        if( is_array( $val ) ) {
            $result[$key] = arrayCopy( $val );
        } elseif ( is_object( $val ) ) {
            $result[$key] = clone $val;
        } else {
            $result[$key] = $val;
        }
    }
    return $result;
}
function buildTable($data){
    $subfields = array('variety','location','boxQuantity','plantQuantity');
    $boxTotal = 0;
    $plantTotal = 0;

    foreach($data as $key => $fulfillment){
        echo '<tr>';
        foreach($subfields as $i => $property){
            echo "<td>$fulfillment[$property]</td>";
        }

        if($fulfillment['boxQuantity']) $boxTotal += intval($fulfillment['boxQuantity']);
        if($fulfillment['plantQuantity']) $plantTotal += intval($fulfillment['plantQuantity']);
        echo '</tr>';
    }

    echo '<tr><td></td><td class="total">Total</td>';
        echo "<td class='total'>$boxTotal boxes</td>";
        echo "<td class='total'>$plantTotal plants</td>";
    echo '</tr>';
}
function buildPallets($data){
    $palletsIn = 0;
    $palletsOut = 0;
    foreach($data as $key => $fulfillment) {
        if($fulfillment['palletsIn']) $palletsIn += intval($fulfillment['palletsIn']);
        if($fulfillment['palletsOut']) $palletsOut += intval($fulfillment['palletsOut']);
    }
    if($palletsIn==0 && $palletsOut==0) return;

    $palletsRemaining = $palletsOut - $palletsIn;
    echo '<ul>';
        echo "<li><span class='key'>Pallets sent:</span> $palletsOut</li>";
        echo "<li><span class='key'>Pallets returned:</span> $palletsIn</li>";
        echo "<li><span class='key'>Pallets out:</span> $palletsRemaining</li>";
    echo '</ul>';
}
?>