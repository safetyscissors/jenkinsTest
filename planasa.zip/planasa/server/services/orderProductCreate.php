<?php
require('authCheck.php');

require('queries/orderQueries.php');

$PAGE->id='orderProductCreate';
$fields = array('orderId','variety','location','boxQuantity','plantsPerBox','plantQuantity');
$requiredFields = array('orderId','variety','plantQuantity');
$inputs=array();
$body = json_decode(file_get_contents("php://input"));

//check POST object for variables from front end
foreach($fields as $key=>$field){
    if(isset($body->{$field}) && !empty($body->{$field})){
        $inputs[$field] = $body->{$field};
    }else{
        $inputs[$field] = "";
    }
}

//check for required fields
foreach($requiredFields as $reqField){
    if(!isset($inputs[$reqField]) || empty($inputs[$reqField]) || $inputs[$reqField]==''){
        return errorHandler("missing $reqField", 503);
    }
}

//print debug statement
if($SERVERDEBUG){
    echo "\r\n inputs:";
    echo json_encode($inputs);
}

//setup for query
$stmt = initAddOrderProducts($DB);
$stmt->bind_param('isssss',$inputs['orderId'],$inputs['variety'],$inputs['location'],$inputs['boxQuantity'],$inputs['plantsPerBox'],$inputs['plantQuantity']);
if(!$stmt) return errorHandler("add subtable order failed to bind param", 503);
if(!$stmt->execute()) return errorHandler("Failed to create this sub order $stmt->errno: $stmt->error", 503);
$orderId = $stmt->insert_id;
$stmt->close();

echo '{"id":"'.$orderId.'"}';

?>
