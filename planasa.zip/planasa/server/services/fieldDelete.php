<?php
require('authCheck.php');
if(!isset($USER->id)) return;
require('queries/fieldQueries.php');
$PAGE->id='fieldDelete';

$inputs=array();
$body = json_decode(file_get_contents("php://input"));

if(isset($body->fieldId) && !empty($body->fieldId)){
    $inputs['fieldId'] = $body->fieldId;
}else{
    return errorHandler("fieldId is required", 503);
}

//setup for query
$stmt = deleteField($DB, $inputs['fieldId']);
if(!$stmt) return; // getLists already send error.
if(!$stmt->execute()) return errorHandler("failed to delete this product $stmt->errno: $stmt->error", 503);

if($stmt->affected_rows != 1){
    return errorHandler("Deleted $stmt->affected_rows rows", 503);
}

?>