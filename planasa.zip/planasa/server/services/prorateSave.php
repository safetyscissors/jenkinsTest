<?php
require('authCheck.php');
require('seasonCheck.php');
if(!isset($USER->id)) return;
require('queries/prorateQueries.php');

$PAGE->id='prorateSave';
$fields = array('variety','location','prorate');
$requiredFields = array('variety','location','prorate');
$inputs=array();
$body = json_decode(file_get_contents("php://input"));

//check POST object for variables from front end
foreach($fields as $key=>$field){
    if(isset($body->{$field}) && !empty($body->{$field})){
        $inputs[$field] = $body->{$field};
    }else{
        $inputs[$field] = "";
    }
}

//check for required fields
foreach($requiredFields as $reqField){
    if(!isset($inputs[$reqField]) || empty($inputs[$reqField]) || $inputs[$reqField]==''){
        return errorHandler("missing $reqField", 503);
    }
}

//print debug statement
if($SERVERDEBUG){
    echo "\r\n inputs:";
    echo json_encode($inputs);
}

//check for existing user
$existingStmt = checkProrateExists($DB, $SEASON, $inputs['variety'], $inputs['location']);
if(!$existingStmt) return; // checkExistingUserEmail already sent an error
if(!$existingStmt->execute()) return errorHandler("Failed to check for existing prorate by variety/location $existingStmt->errno: $existingStmt->error" );

$existingStmt->bind_result($existingId);
$existingStmt->fetch();
$existingStmt->close();

$stmt;
if($existingId){
    $stmt = updateProrate($DB, $inputs['prorate'], $existingId);
}else{
    $stmt = insertProrate($DB, $inputs['prorate'], $SEASON, $inputs['variety'], $inputs['location']);
}
if(!$stmt) return; // queries already sent an error.
if(!$stmt->execute()) return errorHandler("Failed to create this prorate $stmt->errno: $stmt->error", 503);
echo '{"id":"'.$stmt->insert_id.'"}';
$stmt->close();
?>