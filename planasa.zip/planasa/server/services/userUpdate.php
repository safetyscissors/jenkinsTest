<?php
  require('authCheck.php');
  require('authPermissions.php');

  if(!isset($USER->id)) return;
  if(!authPermissionCheck($USER,'users')) return;

  require('queries/userQueries.php');
  $PAGE->id='userUpdate';

  $requiredFields=array('userId','email','name');
  $inputs=array();
  $put = json_decode(file_get_contents("php://input"));

  //check POST object for variables from front end
  if(isset($put->userId)) $inputs['userId'] = $put->userId;
  if(isset($put->email)) $inputs['email'] = $put->email;
  if(isset($put->name)) $inputs['name'] = $put->name;
  $inputs['permissions'] = (isset($put->permissions))? $put->permissions : '';

  //check inputs for all required fields 
  foreach($requiredFields as $postKey){
    if(!isset($inputs[$postKey]) || empty($inputs[$postKey])){
      return errorHandler("missing $postKey", 503);
    }
  }

  //print debug statement
  if($SERVERDEBUG){
    echo "\r\n inputs:";
    echo json_encode($inputs);
  }

  //setup for query
  $stmt = updateUser($DB, $inputs['userId'], $inputs['email'], $inputs['name'], $inputs['permissions']);
  if(!$stmt) return; // createNewList already send error.
  if(!$stmt->execute()) return errorHandler("failed to create this list $stmt->errno: $stmt->error");

  if($stmt->affected_rows != 1){
    return errorHandler("Updated $stmt->affected_rows rows", 503);
  }
  echo json_encode($inputs);
?>  