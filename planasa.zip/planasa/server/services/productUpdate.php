<?php
require('authCheck.php');
require('authPermissions.php');

if(!isset($USER->id)) return;
if(!authPermissionCheck($USER,'product')) return;

require('queries/productQueries.php');
$PAGE->id='productUpdate';
$fields = array('productId','variety','location','plantsPerBox');
$requiredFields=array('productId','variety');
$inputs=array();
$put = json_decode(file_get_contents("php://input"));

//check input object for variables from front end
foreach($fields as $key=>$field){
    if(isset($put->{$field}) && !empty($put->{$field})){
        $inputs[$field] = $put->{$field};
    }else{
        $inputs[$field] = "";
        if($field=='plantsPerBox') $inputs[$field] = 0;
    }
}

//check inputs for all required fields
foreach($requiredFields as $postKey){
    if(!isset($inputs[$postKey]) || empty($inputs[$postKey]) || $inputs[$postKey]==""){
        return errorHandler("missing $postKey", 503);
    }
}

//print debug statement
if($SERVERDEBUG){
    echo "\r\n inputs:";
    echo json_encode($inputs);
}

//setup for query
$stmt = updateProduct($DB, $inputs['productId'],$inputs['variety'],$inputs['location'],$inputs['plantsPerBox']);
if(!$stmt) return; // createNewList already send error.
if(!$stmt->execute()) return errorHandler("failed to create this list $stmt->errno: $stmt->error");

if($stmt->affected_rows != 1){
    return errorHandler("Updated $stmt->affected_rows rows", 503);
}
echo json_encode($inputs);
?>