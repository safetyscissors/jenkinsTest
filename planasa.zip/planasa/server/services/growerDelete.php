<?php
require('authCheck.php');
if(!isset($USER->id)) return;
require('queries/growerQueries.php');
$PAGE->id='growerDelete';

$inputs=array();
$_DELETE = json_decode(file_get_contents("php://input"));

if(isset($_DELETE->growerId) && !empty($_DELETE->growerId)){
    $inputs['growerId'] = $_DELETE->growerId;
}else{
    return errorHandler("GrowerId is required", 503);
}

//setup for query
$stmt = deleteGrower($DB, $inputs['growerId']);
if(!$stmt) return; // getLists already send error.
if(!$stmt->execute()) return errorHandler("failed to delete this grower $stmt->errno: $stmt->error", 503);

if($stmt->affected_rows != 1){
    return errorHandler("Deleted $stmt->affected_rows rows", 503);
}

?>