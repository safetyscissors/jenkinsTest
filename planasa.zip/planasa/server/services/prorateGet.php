<?php
require('authCheck.php');
require('seasonCheck.php');

require('queries/prorateQueries.php');

$PAGE->id='prorateGet';

$inputs=array();
if(!isset($_GET['variety']) || empty($_GET['variety'])) return errorHandler("missing variety", 503);
if(!isset($_GET['location']) || empty($_GET['location'])) return errorHandler("missing location", 503);

$inputs['variety'] = $_GET['variety'];
$inputs['location'] = $_GET['location'];

//print debug statement
if($SERVERDEBUG){
    echo "\r\n inputs:";
    echo json_encode($inputs);
}

//setup for query
$stmt = getProrate($DB, $SEASON, $inputs['variety'], $inputs['location']);
if(!$stmt) return; // stmt already send error.
if(!$stmt->execute()) return errorHandler("failed to get this prorate $stmt->errno: $stmt->error");
//format results
$data = array();
$stmt->bind_result($data['prorate']);

/* fetch values */
$stmt->fetch();
$stmt->close();

echo json_encode($data);
?>

