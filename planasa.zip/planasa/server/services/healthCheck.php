<?php
  require('authCheck.php');
  $PAGE->id='healthy';
  echo 'hi';
?>