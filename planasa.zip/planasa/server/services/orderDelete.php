<?php
require('authCheck.php');
if(!isset($USER->id)) return;
require('queries/orderQueries.php');
$PAGE->id='orderDelete';

$inputs=array();
$_DELETE = json_decode(file_get_contents("php://input"));

if(isset($_DELETE->orderId) && !empty($_DELETE->orderId)){
    $inputs['orderId'] = $_DELETE->orderId;
}else{
    return errorHandler("OrderId is required", 503);
}

//delete all sub order lines
$ordersStmt = deleteAllOrdersByOrderId($DB, $inputs['orderId']);
if(!$ordersStmt) return; // getLists already send error.
if(!$ordersStmt->execute()) return errorHandler("failed to delete all sub orders $ordersStmt->errno: $ordersStmt->error", 503);
$ordersStmt->close();

//delete the order
$stmt = deleteOrder($DB, $inputs['orderId']);
if(!$stmt) return; // getLists already send error.
if(!$stmt->execute()) return errorHandler("failed to delete this order $stmt->errno: $stmt->error", 503);
if($stmt->affected_rows != 1) return errorHandler("Deleted $stmt->affected_rows rows", 503);
$stmt->close();

?>