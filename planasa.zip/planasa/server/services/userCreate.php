<?php
  require('authCheck.php');
if(!isset($USER->id)) return;
  require('queries/userQueries.php');
  require('password_compat.php');
  $PAGE->id='userCreate';

  $fields=array('email','name','password','permissions');
  $inputs=array();

$body = json_decode(file_get_contents("php://input"));

//check POST object for variables from front end
foreach($fields as $key=>$field){
  if(isset($body->{$field}) && !empty($body->{$field})){
    $inputs[$field] = $body->{$field};
  }else{
    $inputs[$field] = "";
    if($field == 'password'){
      $inputs[$field] = 'changeme';
    }
  }
}

  //print debug statement
  if($SERVERDEBUG){
    echo "\r\n inputs:";
    echo json_encode($inputs);
  }

  //check for existing user
  $existingStmt = checkExistingUserEmail($DB, $inputs['email']);
  if(!$existingStmt) return; // checkExistingUserEmail already sent an error
  if(!$existingStmt->execute()) return errorHandler("Failed to check for existing user by email $existingStmt->errno: $existingStmt->error" );

  $existingStmt->bind_result($existingId);
  $existingStmt->fetch();
  $existingStmt->close();
  if($existingId!=0) return errorHandler("Can't create this user. Email is currently in use.");

  //create passwordHash for db
  $passwordHash = password_hash($inputs['password'], PASSWORD_BCRYPT, array('cost'=>11));

  //setup for query
  $stmt = createUser($DB, $inputs['email'], $inputs['name'], $inputs['permissions'], $passwordHash);
  if(!$stmt) return; // createNewList already sent an error.
  if(!$stmt->execute()) return errorHandler("Failed to create this user $stmt->errno: $stmt->error");
  echo '{"id":"'.$stmt->insert_id.'"}';

?>
