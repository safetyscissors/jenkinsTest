<?php
require('authCheck.php');
require('seasonCheck.php');
if(!isset($USER->id)) return;
require('queries/fulfillmentQueries.php');
$PAGE->id='fulfillmentListByOrder';

//get inputs. requires listId
$requiredField='orderId';
$input='';
if(isset($_GET[$requiredField]) && !empty($_GET[$requiredField])){
    $input=$_GET[$requiredField];
}else{
    return errorHandler("Missing $requiredField", 503);
}

//setup for query
$stmt = getFulfillmentListByOrder($DB,$SEASON,$input);
if(!$stmt->execute()) return errorHandler("failed to get this list $stmt->errno: $stmt->error");
//format results
$data = array();
$stmt->bind_result(
    $data['fulfillmentId'],
    $data['fulfillmentNumber'],
    $data['orderNumber'],
    $data['createdDate'],
    $data['season'],
    $data['notes'],
    $data['status'],
    $data['fulfillmentItemId'],
    $data['variety'],
    $data['location'],
    $data['plantQuantity'],
    $data['field'],
    $data['shed'],
    $data['cooler'],
    $data['truck'],
    $data['growerName']
);

// fetch values
$listResults = array();
while ($stmt->fetch()) {
    $row = arrayCopy($data);
    array_push($listResults, $row);
}
$stmt->close();

echo json_encode($listResults);

function arrayCopy( array $array ) {
    $result = array();
    foreach( $array as $key => $val ) {
        if( is_array( $val ) ) {
            $result[$key] = arrayCopy( $val );
        } elseif ( is_object( $val ) ) {
            $result[$key] = clone $val;
        } else {
            $result[$key] = $val;
        }
    }
    return $result;
}
?>