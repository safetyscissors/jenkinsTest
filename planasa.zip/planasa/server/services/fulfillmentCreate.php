<?php
require('authCheck.php');
require('seasonCheck.php');

if(!isset($USER->id)) return;
require('queries/fulfillmentQueries.php');

$PAGE->id='fulfillmentCreate';

$fields = array('orderId','orderNumber','createdDate','deliveredDate','season','notes');
$requiredFields = array();
$inputs=array();
$body = json_decode(file_get_contents("php://input"));

//check POST object for variables from front end
foreach($fields as $key=>$field){
    if(isset($body->{$field}) && !empty($body->{$field})){
        $inputs[$field] = $body->{$field};
    }else{
        $inputs[$field] = "";
    }
}

//print debug statement
if($SERVERDEBUG){
    echo "\r\n inputs:";
    echo json_encode($inputs);
}

//setup for query
$stmt = createFulfillment($DB,
    $inputs['orderId'],
    $inputs['orderNumber'],
    $inputs['createdDate'],
    $inputs['deliveredDate'],
    $SEASON,
    $inputs['notes']
);



if(!$stmt) return; // stmt already sent an error.
if(!$stmt->execute()) return errorHandler("Failed to create this fulfillment $stmt->errno: $stmt->error", 503);
$fulfillmentId = $stmt->insert_id;
$stmt->close();

//add varieties
if($inputs['orderId']){
    $addVarieties = prefillVarieties($DB, $inputs['orderId'], $fulfillmentId, $inputs['createdDate']);
    if(!$addVarieties->execute()) return errorHandler("Failed to prefill this fulfillment $addVarieties->errno: $addVarieties->error", 503);
    $addVarieties->close();
}

echo '{"id":"'.$fulfillmentId.'"}';

?>
