<?php
  require('authCheck.php');
  unset($_SESSION['userId']);
  unset($_SESSION['name']);
  unset($_SESSION['time']);
  unset($_SESSION['permissions']);
?>

