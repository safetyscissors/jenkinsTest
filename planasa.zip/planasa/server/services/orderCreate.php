<?php
require('authCheck.php');
require('seasonCheck.php');
require('queries/orderQueries.php');

$PAGE->id='orderCreate';
$fields = array('orderDate','deliveryDate','season','notes','growerId','growerName','variety','location','plantsPerBox','boxQuantity','orders');
//$requiredFields = array('orderDate','growerId','growerName','plantsPerBox','boxQuantity','variety','location');
$requiredFields = array();
$inputs=array();
$body = json_decode(file_get_contents("php://input"));

//check POST object for variables from front end
foreach($fields as $key=>$field){
    if(isset($body->{$field}) && !empty($body->{$field})){
        $inputs[$field] = $body->{$field};
    }else{
        $inputs[$field] = "";
        if($field==='plantsPerBox') $inputs[$field] = 0;
        if($field==='boxQuantity') $inputs[$field] = 0;
    }
}

//check for required fields
foreach($requiredFields as $reqField){
    if(!isset($inputs[$reqField]) || empty($inputs[$reqField]) || $inputs[$reqField]==''){
        return errorHandler("missing $reqField", 503);
    }
}

//print debug statement
if($SERVERDEBUG){
    echo "\r\n inputs:";
    echo json_encode($inputs);
}

//check for existing order
/*
$existingStmt = checkExistingOrder($DB, $inputs['deliveryDate'], $inputs['growerId'], $inputs['variety'], $inputs['location'], $inputs['boxQuantity']);
if(!$existingStmt) return; // stmt already sent an error
if(!$existingStmt->execute()) return errorHandler("Failed to check for existing order by grower/variety/delivery date $existingStmt->errno: $existingStmt->error" );

$existingStmt->bind_result($existingId);
$existingStmt->fetch();
$existingStmt->close();

if($existingId!=0) return errorHandler("Can't create this product. Variety/Grower/Quantity/Date is currently in use.", 503);
*/

//setup for query
$stmt = createOrder($DB,
    "",
    $inputs['orderDate'],
    $inputs['deliveryDate'],
    $SEASON,
    $inputs['notes'],
    $inputs['growerId'],
    $inputs['growerName'],
    $inputs['variety'],
    $inputs['location'],
    $inputs['plantsPerBox'],
    $inputs['boxQuantity']
);

if(!$stmt) return; // stmt already sent an error.
if(!$stmt->execute()) return errorHandler("Failed to create this order $stmt->errno: $stmt->error", 503);
$orderId = $stmt->insert_id;
$stmt->close();

if(isset($inputs['orders']) && !empty($inputs['orders'])){
    for($i=0;$i<count($inputs['orders']);$i++){
        $order = $inputs['orders'][$i];
        $orderStmt = initAddOrderProducts($DB);
        if(!$orderStmt) return errorHandler("Failed to init order subquery.", 503);
        $orderStmt->bind_param('isssss',$orderId,$order->variety,$order->location,$order->boxQuantity,$order->plantsPerBox,$order->plantQuantity);
        if(!$orderStmt) return errorHandler("Failed to bind order subquery.", 503);
        if(!$orderStmt->execute()) return errorHandler("Failed to execute order subquery.", 503);
        $orderStmt->close();
    }
}

$orderNumber = "".$orderId;
for($i=strlen($orderNumber);$i<8;$i++){
    $orderNumber = "0".$orderNumber;
}
$orderNumber = "16".$orderNumber;

$orderNumberStmt = saveOrderNumber($DB, $orderId, $orderNumber);
if(!$orderNumberStmt) return; // stmt already sent an error.
if(!$orderNumberStmt->execute()) return errorHandler("Failed to create this order $orderNumberStmt->errno: $orderNumberStmt->error", 503);
$orderNumberStmt->close();

echo '{"id":"'.$orderId.'"}';

?>
