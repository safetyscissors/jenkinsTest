<?php
    function authPermissionCheck($USER, $level){
        return true;
        //if page is public, return all.
        if($level == 'all') return true;
        
        //if page requires something, and user has 0 permissions, return error
        if(count($USER->permissions) == 0) return errorHandler('Unauthorized. User has no permissions',401);

        //if page requires something and user does have it, return true
        $matchingPermissions = false;
        $PAGE['permissions'] = $USER->permissions;
        foreach($USER->permissions as $permission){
            if($permission == $level) $matchingPermissions = true;
        }
        if($matchingPermissions) return true;

        //if user doesnt have it, return error.
        return errorHandler("Unauthorized. User does not have $level permissions",401);
    }
?>