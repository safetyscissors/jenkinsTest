<?php
require('authCheck.php');

require('queries/fulfillmentQueries.php');

$PAGE->id='fulfillmentItemCreate';
$fields = array('fulfillmentId','productId','pickDate','variety','location','plantsPerBox','boxQuantity','plantQuantity','field','cooler','shed','truck','palletsIn','palletsOut');
$requiredFields = array('fulfillmentId','variety');
$inputs=array();
$body = json_decode(file_get_contents("php://input"));

//check POST object for variables from front end
foreach($fields as $key=>$field){
    if(isset($body->{$field}) && !empty($body->{$field})){
        $inputs[$field] = $body->{$field};
    }else{
        $inputs[$field] = "";
    }
}

//check for required fields
foreach($requiredFields as $reqField){
    if(!isset($inputs[$reqField]) || empty($inputs[$reqField]) || $inputs[$reqField]==''){
        return errorHandler("missing $reqField", 503);
    }
}

//print debug statement
if($SERVERDEBUG){
    echo "\r\n inputs:";
    echo json_encode($inputs);
}

//setup for query
$stmt = addFulfillmentItem($DB,$inputs['fulfillmentId'],$inputs['productId'],$inputs['pickDate'],$inputs['variety'],$inputs['location'],$inputs['plantsPerBox'],$inputs['boxQuantity'],$inputs['plantQuantity'],$inputs['field'],$inputs['cooler'],$inputs['shed'],$inputs['truck'],$inputs['palletsIn'],$inputs['palletsOut']);
if(!$stmt->execute()) return errorHandler("Failed to create this sub fulfillment $stmt->errno: $stmt->error", 503);
$subFulfillmentId = $stmt->insert_id;
$stmt->close();

echo '{"id":"'.$subFulfillmentId.'"}';

?>
