<?php
require('authCheck.php');

require('queries/growerQueries.php');

$PAGE->id='growerCreate';
$fields = array('name','county','countyShort','clubName','addresses','contact','phone','fax','email','notes');
$requiredFields = array('name');
$inputs=array();
$body = json_decode(file_get_contents("php://input"));

//check POST object for variables from front end
foreach($fields as $key=>$field){
    if(isset($body->{$field}) && !empty($body->{$field})){
        $inputs[$field] = $body->{$field};
    }else{
        $inputs[$field] = "";
    }
}

//check for required fields
foreach($requiredFields as $reqField){
    if(!isset($inputs[$reqField]) || empty($inputs[$reqField]) || $inputs[$reqField]==''){
        return errorHandler("missing $reqField", 503);
    }
}

//print debug statement
if($SERVERDEBUG){
    echo "\r\n inputs:";
    echo json_encode($inputs);
}

//check for existing user
$existingStmt = checkExistingGrower($DB, $inputs['name']);
if(!$existingStmt) return; // checkExistingUserEmail already sent an error
if(!$existingStmt->execute()) return errorHandler("Failed to check for existing grower by name $existingStmt->errno: $existingStmt->error" );

$existingStmt->bind_result($existingId);
$existingStmt->fetch();
$existingStmt->close();

if($existingId!=0) return errorHandler("Can't create this grower. Name is currently in use.", 503);

//setup for query
$stmt = createGrower($DB, $inputs['name'],$inputs['county'],$inputs['countyShort'],$inputs['clubName'],$inputs['addresses'],$inputs['contact'],$inputs['phone'],$inputs['fax'],$inputs['email'],$inputs['notes']);
if(!$stmt) return; // createNewList already sent an error.
if(!$stmt->execute()) return errorHandler("Failed to create this grower $stmt->errno: $stmt->error", 503);
echo '{"id":"'.$stmt->insert_id.'"}';

?>
