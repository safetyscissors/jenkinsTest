<?php
require('authCheck.php');
if(!isset($USER->id)) return;
require('queries/fulfillmentQueries.php');
$PAGE->id='fulfillmentGet';

//get inputs. requires listId
$requiredField='fulfillmentId';
$input='';
if(isset($_GET[$requiredField]) && !empty($_GET[$requiredField])){
    $input=$_GET[$requiredField];
}else{
    return errorHandler("Missing $requiredField", 503);
}

//setup for query
$stmt = getFulfillment($DB, $input);
if(!$stmt) return; // stmt already send error.
if(!$stmt->execute()) return errorHandler("failed to get this list $stmt->errno: $stmt->error");
//format results
$data = array();
$stmt->bind_result(
    $data['fulfillmentId'],
    $data['fulfillmentNumber'],
    $data['orderId'],
    $data['orderNumber'],
    $data['orderDate'],
    $data['createdDate'],
    $data['deliveredDate'],
    $data['season'],
    $data['notes'],
    $data['status'],
    $data['fulfillmentItemId'],
    $data['pickDate'],
    $data['variety'],
    $data['location'],
    $data['plantsPerBox'],
    $data['boxQuantity'],
    $data['plantQuantity'],
    $data['field'],
    $data['shed'],
    $data['cooler'],
    $data['truck'],
    $data['palletsIn'],
    $data['palletsOut'],
    $data['growerName']


);

/* fetch values */
$res;
while($stmt->fetch()){
    if(!isset($res['fulfillmentId']) || empty($res['fulfillmentId'])){
        $res = $data;
        $res['fulfillments']= array();
    }

    $fulfillmentItemFields = array('fulfillmentItemId','pickDate','variety','location','plantsPerBox','boxQuantity','plantQuantity','field','shed','cooler','truck','palletsIn','palletsOut');
    if(isset($data['fulfillmentItemId']) && !empty($data['fulfillmentItemId'])) {
        array_push($res['fulfillments'], fillObj($data, $fulfillmentItemFields));
    }
}
$stmt->close();

echo json_encode($res);

function fillObj($data, $keys){
    $result = array();
    foreach($keys as $index=>$key){
        $result[$key] = $data[$key];
    }
    return $result;
}
function arrayCopy( array $array ) {
    $result = array();
    foreach( $array as $key => $val ) {
        if( is_array( $val ) ) {
            $result[$key] = arrayCopy( $val );
        } elseif ( is_object( $val ) ) {
            $result[$key] = clone $val;
        } else {
            $result[$key] = $val;
        }
    }
    return $result;
}
?>

