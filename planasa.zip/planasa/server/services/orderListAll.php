<?php
require('authCheck.php');
require('seasonCheck.php');
if(!isset($USER->id)) return;
require('queries/orderQueries.php');
$PAGE->id='orderListAll';

//setup for query
$stmt = getOrderList($DB,$SEASON);
if(!$stmt->execute()) return errorHandler("failed to get this list $stmt->errno: $stmt->error");
//format results
$data = array();
$stmt->bind_result($data['orderId'],$data['orderNumber'],$data['orderDate'],$data['deliveryDate'],$data['season'],$data['notes'],$data['status'],$data['countyShort'],$data['growerName'],$data['variety'],$data['location'],$data['plantsPerBox'],$data['boxQuantity'],$data['plantQuantity']);

// fetch values
$listResults = array();
while ($stmt->fetch()) {
    $row = arrayCopy($data);
    array_push($listResults, $row);
}
$stmt->close();

// get products for each order
for($i=0;$i<count($listResults);$i++) {
    if (is_numeric($listResults[$i]['orderId'])) {
        $listResults[$i]['orders'] = array();

        $productsStmt = getOrderProducts($DB, $listResults[$i]['orderId']);
        if (!$productsStmt->execute()) return errorHandler("failed to get this order's list $productsStmt->errno: $productsStmt->error");
        //format results
        $productData = array();
        $productsStmt->bind_result($productData['productId'],$productData['variety'],$productData['location'],$productData['boxQuantity'],$productData['plantsPerBox'],$productData['plantsQuantity']);

        while ($productsStmt->fetch()) {
            $productRow = arrayCopy($productData);
            array_push($listResults[$i]['orders'], $productRow);
        }
        $productsStmt->close();

    }

}



echo json_encode($listResults);

function arrayCopy( array $array ) {
    $result = array();
    foreach( $array as $key => $val ) {
        if( is_array( $val ) ) {
            $result[$key] = arrayCopy( $val );
        } elseif ( is_object( $val ) ) {
            $result[$key] = clone $val;
        } else {
            $val = utf8_encode($val);
            $result[$key] = $val;
        }
    }
    return $result;
}
?>