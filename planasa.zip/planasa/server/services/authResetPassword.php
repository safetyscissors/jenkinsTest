<?php
    require('queries/userQueries.php');
    require('password_compat.php');
    $PAGE->id='authResetPassword';

    //requires email
    $inputs=array();
    if(isset($_POST['email']) && !empty($_POST['email'])){
        $inputs['email']=$_POST['email'];
    }else{
        return errorHandler("missing email", 503);
    }

    //get user
    $stmt = getUserByEmail($DB, $inputs['email']);
    if(!$stmt) return; //authLogin already sent an error.
    if(!$stmt->execute()) return errorHandler("failed to create this list $stmt->errno: $stmt->error");
    $data = array();
    $stmt->bind_result($data['id'],$data['name'],$data['hash'], $data['permissions']);
    $stmt->fetch();

    if(empty($data['id'])) return errorHandler("email does not exist", 503);
    $stmt->close();

    //reset password
    $newPassword = $inputs['email'].time();
    $passwordHash = password_hash($newPassword, PASSWORD_BCRYPT, array('cost'=>11));

    //save passwordReset
    $passwordStmt = updateUserReset($DB, $data['id'], $passwordHash);
    if(!$passwordStmt) return; // createNewList already send error.
    if(!$passwordStmt->execute()) return errorHandler("failed to create this user $passwordStmt->errno: $passwordStmt->error");

    if($passwordStmt->affected_rows != 1){
        return errorHandler("Updated $passwordStmt->affected_rows rows", 503);
    }
echo 'd';
    //send email
/*
    $BASEURL = "http://localhost/planasa";
    $newUrl = $BASEURL;//."/authNewPassword?request=".$newPassword;
    $msg = array(
        "Your Planasa Inventory account password was reset.",
        "To reset your password, click <a href='$newUrl'>here</a>",
        "If your email doesnt display the link correctly, you can go to $newUrl.",
        "If you did not reset your password, you can ignore this email and the request will reset in 24 hrs."
    );
    $msg = join("<br>"."\n",$msg);

    echo 'b';
//echo $msg;
*/

?>