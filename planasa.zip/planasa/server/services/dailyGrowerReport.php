<?php
require('authCheck.php');
require('seasonCheck.php');
if(!isset($USER->id)) return;
require('queries/fulfillmentQueries.php');
require('queries/orderQueries.php');
require('queries/reportQueries.php');
$PAGE->id='dailyReport';

//get inputs. requires listId
$fields = array('variety','location');
$inputs=array();

//check POST object for variables from front end
foreach($fields as $key=>$field){
    if(isset($_GET[$field]) && !empty($_GET[$field])){
        $inputs[$field] = $_GET[$field];
    }else{
        return errorHandler("missing $field", 503);
    }
}

//setup for query
$orderStmt = getOrdersByVarietyAndGrower($DB, $SEASON, $inputs['variety'], $inputs['location']);
if(!$orderStmt->execute()) return errorHandler("failed to get this list $orderStmt->errno: $orderStmt->error");
//format results
$data = array();
$orderStmt->bind_result(
    $data['growerId'],
    $data['growerName'],
    $data['clubName'],
    $data['plantQuantity']
);

// fetch values
$orderResults = array();
while ($orderStmt->fetch()) {
    $row = arrayCopy($data);
    array_push($orderResults, $row);
}
$orderStmt->close();

//setup for query
$stmt = getFulfillmentsByVarietyAndGrower($DB, $SEASON, $inputs['variety'], $inputs['location']);
if(!$stmt->execute()) return errorHandler("failed to get this list $stmt->errno: $stmt->error");
//format results
$data = array();
$stmt->bind_result(
    $data['growerId'],
    $data['plantQuantity']
);

// fetch values
$fulfillmentResults = array();
while ($stmt->fetch()) {
    $row = arrayCopy($data);
    array_push($fulfillmentResults, $row);
}
$stmt->close();

$results = new stdClass();
$results->orders = $orderResults;
$results->fulfillments = $fulfillmentResults;

echo json_encode($results);

function arrayCopy( array $array ) {
    $result = array();
    foreach( $array as $key => $val ) {
        if( is_array( $val ) ) {
            $result[$key] = arrayCopy( $val );
        } elseif ( is_object( $val ) ) {
            $result[$key] = clone $val;
        } else {
            $val = utf8_encode($val);
            $result[$key] = $val;
        }
    }
    return $result;
}

?>