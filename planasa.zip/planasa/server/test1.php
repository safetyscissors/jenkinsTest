<?php
    require('services/authPermissions.php');
    echo authPermissionCheck('admin');
?>