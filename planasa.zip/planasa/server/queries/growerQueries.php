<?php
/* ************************************************************* *\
                    USER SERVICE FUNCTIONS
\* ************************************************************* */

    function getGrower($DB, $growerId){
        $stmt = $DB->prepare("SELECT growerId,name,county,countyShort,clubName,addresses,contact,phone,fax,email,notes FROM growers WHERE growerId = ?");
        if(!$stmt->bind_param('i', $growerId)){
            return errorHandler("getGrower failed to bind parameter", 503);
        }
        return $stmt;
    }

    function checkExistingGrower($DB, $growerName){
        $stmt = $DB->prepare("SELECT growerId FROM growers WHERE name = ?");
        if(!$stmt || !$stmt->bind_param('s', $growerName)){
            return errorHandler("checkExistingGrower failed to bind paramter", 503);
        }
        return $stmt;
    }

    function createGrower($DB, $gName, $gCounty, $gCountyShort, $gClubName, $gAddresses, $gContact, $gPhone, $gFax, $gEmail, $gNotes){
        $stmt = $DB->prepare("INSERT INTO growers (name, county, countyShort, clubName, addresses, contact, phone, fax, email, notes) VALUES (?,?,?,?,?,?,?,?,?,?)");
        if(!$stmt || !$stmt->bind_param('ssssssssss', $gName, $gCounty, $gCountyShort, $gClubName, $gAddresses, $gContact, $gPhone, $gFax, $gEmail, $gNotes)){
            return errorHandler("createGrower failed to bind parameter", 503);
        }
        return $stmt;
    }

    function getGrowerList($DB){
        $stmt = $DB->prepare("SELECT growerId, name, countyShort, clubName, contact, notes FROM growers");
        if(!$stmt) return errorHandler("getGrowerList failed to create query", 503);

        return $stmt;
    }

    function deleteGrower($DB, $growerId){
        $stmt = $DB->prepare("DELETE FROM growers WHERE growerId = ?");
        if(!$stmt || !$stmt->bind_param('i', $growerId)){
            return errorHandler("deleteGrower failed to create query", 503);
        }

        return $stmt;
    }

    function updateGrower($DB, $growerId, $gName, $gCounty, $gCountyShort, $gClubName, $gAddresses, $gContact, $gPhone, $gFax, $gEmail, $gNotes){
        $stmt = $DB->prepare("UPDATE growers SET name=?, county=?, countyShort=?, clubName=?, addresses=?, contact=?, phone=?, fax=?, email=?, notes=? WHERE growerId=?");
        if(!$stmt || !$stmt->bind_param('ssssssssssi', $gName, $gCounty, $gCountyShort, $gClubName, $gAddresses, $gContact, $gPhone, $gFax, $gEmail, $gNotes, $growerId)){
            return errorHandler("updateGrower failed to bind parameter", 503);
        }

        return $stmt;
    }

    function getGrowerClubList($DB){
        $stmt = $DB->prepare("SELECT clubName, count(growerId) AS count FROM growers GROUP BY clubName");
        if(!$stmt) return errorHandler("getGrowerClubList failed to create query",503);
        return $stmt;
    }

    function getGrowerClub($DB, $clubName){
        $stmt = $DB->prepare("SELECT growerId, name, countyShort, clubName, contact, notes FROM growers WHERE clubName = ?");
        if(!$stmt || !$stmt->bind_param('s', $clubName)){
            return errorHandler("getGrowerClub failed to create query", 503);
        }
        return $stmt;
    }
?>