<?php

function getFulfillmentList($DB,$season){
    $infoFields = "a.fulfillmentId, a.fulfillmentNumber, a.orderNumber, a.createdDate, a.season, a.notes, a.status";
    $fulfillmentFields = "b.fulfillmentItemId, b.variety, b.location, b.plantQuantity, b.field, b.shed, b.cooler, b.truck";
    $orderFields = "c.growerName";

    $select = "SELECT $infoFields, $fulfillmentFields, $orderFields FROM fulfillmentInformation AS a ";
    $select.= "LEFT JOIN fulfillments AS b ON a.fulfillmentId = b.fulfillmentId ";
    $select.= "LEFT JOIN orderInformation AS c ON a.orderId = c.orderId ";
    $select.= "WHERE a.season = ? LIMIT 1000";

    $stmt = $DB->prepare($select);
    if(!$stmt || !$stmt->bind_param('s', $season)){
        return errorHandler("getFulfillmentList failed to create stmt", 503);
    }
    return $stmt;
}

function getFulfillmentListSearch($DB, $season, $searchTerms, $status){

    $whereClause = "";
    $searchFields = array("a.fulfillmentNumber", "a.orderNumber", "a.createdDate", "a.season", "a.notes", "a.status", "b.variety", "b.location", "b.plantQuantity", "b.shed","b.cooler","b.truck", "c.growerName");

    if(count($searchTerms)>0){
        $whereClause = "WHERE ";
        $andJoins = array();

        for($i=0;$i<count($searchTerms);$i++){
            $orJoins = array();
            $searchTerm = $DB->real_escape_string($searchTerms[$i]);
            $searchTerm = ' LIKE "%'.$searchTerm.'%"';
            for($j=0;$j<count($searchFields);$j++){
                array_push($orJoins,$searchFields[$j].$searchTerm);
            }
            $andJoins[$i] = "(".implode(' OR ',$orJoins).")";
        }
        if($status && $status != 'all') array_push($andJoins,'a.status = "'.$status.'"');
        array_push($andJoins,'a.season = ?');

        $whereClause.= implode(' AND ',$andJoins);
    }else{
        $whereClause = "WHERE a.season = ?";
    }



    $infoFields = "a.fulfillmentId, a.fulfillmentNumber, a.orderNumber, a.createdDate, a.season, a.notes, a.status";
    $fulfillmentFields = "b.fulfillmentItemId, b.variety, b.location, b.plantQuantity, b.field, b.shed, b.cooler, b.truck";
    $orderFields = "c.growerName";

    $select = "SELECT $infoFields, $fulfillmentFields, $orderFields FROM fulfillmentInformation AS a ";
    $select.= "LEFT JOIN fulfillments AS b ON a.fulfillmentId = b.fulfillmentId ";
    $select.= "LEFT JOIN orderInformation AS c ON a.orderId = c.orderId ";
    $select.= $whereClause." ";
    $select.= "LIMIT 1000";

    $stmt = $DB->prepare($select);
    if(!$stmt || !$stmt->bind_param('s', $season)){
        return errorHandler("getFulfillmentList failed to create stmt", 503);
    }

    return $stmt;
}

function getFulfillmentListByOrder($DB, $season, $orderId){
    $infoFields = "a.fulfillmentId, a.fulfillmentNumber, a.orderNumber, a.createdDate, a.season, a.notes, a.status";
    $fulfillmentFields = "b.fulfillmentItemId, b.variety, b.location, b.plantQuantity, b.field, b.shed, b.cooler, b.truck";
    $orderFields = "c.growerName";

    $select = "SELECT $infoFields, $fulfillmentFields, $orderFields FROM fulfillmentInformation AS a ";
    $select.= "LEFT JOIN fulfillments AS b ON a.fulfillmentId = b.fulfillmentId ";
    $select.= "LEFT JOIN orderInformation AS c ON a.orderId = c.orderId ";
    $select.= "WHERE a.orderId=? AND a.season = ?";

    $stmt = $DB->prepare($select);
    if(!$stmt || !$stmt->bind_param('is', $orderId, $season)){
        return errorHandler("getFulfillmentListByOrder failed to create stmt", 503);
    }
    return $stmt;
}

function getFulfillment($DB, $fulfillmentId){
    $infoFields = "a.fulfillmentId, a.fulfillmentNumber, a.orderId, a.orderNumber, c.orderDate, a.createdDate, a.deliveredDate, a.season, a.notes, a.status";
    $fulfillmentFields = "b.fulfillmentItemId, b.pickDate, b.variety, b.location, b.plantsPerBox, b.boxQuantity, b.plantQuantity, b.field, b.shed, b.cooler, b.truck, b.palletsIn, b.palletsOut";
    $orderFields = "c.growerName";

    $select = "SELECT $infoFields, $fulfillmentFields, $orderFields FROM fulfillmentInformation AS a ";
    $select.= "LEFT JOIN fulfillments AS b ON a.fulfillmentId = b.fulfillmentId ";
    $select.= "LEFT JOIN orderInformation AS c ON a.orderId = c.orderId ";
    $select.= "WHERE a.fulfillmentId=? ";

    $stmt = $DB->prepare($select);
    if(!$stmt || !$stmt->bind_param('i', $fulfillmentId)){
        return errorHandler("getFulfillment failed to create stmt", 503);
    }
    return $stmt;
}

function createFulfillment($DB, $orderId, $orderNumber, $createdDate, $deliveredDate, $season, $notes){
    $stmt = $DB->prepare("INSERT INTO fulfillmentInformation (orderId, orderNumber, createdDate, deliveredDate, season, notes) VALUES (?,?,?,?,?,?)");
    if(!$stmt || !$stmt->bind_param('isssss', $orderId, $orderNumber, $createdDate, $deliveredDate, $season, $notes)){
        return errorHandler("createFulfillment failed to bind parameter", 503);
    }
    return $stmt;
}

function prefillVarieties($DB, $orderId, $fulfillmentId){
    $sql = "INSERT INTO fulfillments (variety, location, plantsPerBox, fulfillmentId ) ";
    $sql.= "SELECT variety, location, plantsPerBox, $fulfillmentId AS fulfillmentId FROM orders WHERE orderId = ? ";

    $stmt = $DB->prepare($sql);
    if(!$stmt || !$stmt->bind_param('i', $orderId)){
        return errorHandler("prefillVarieties failed to bind parameter", 503);
    }
    return $stmt;
}

function updateFulfillment($DB, $fulfillmentId, $orderId, $orderNumber, $createdDate, $deliveredDate, $season, $notes, $status){
    $stmt = $DB->prepare("UPDATE fulfillmentInformation SET orderId=?,orderNumber=?,createdDate=?,deliveredDate=?,season=?,notes=?,status=? WHERE fulfillmentId=?");
    if(!$stmt || !$stmt->bind_param('issssssi', $orderId, $orderNumber, $createdDate, $deliveredDate, $season, $notes, $status, $fulfillmentId)){
        return errorHandler("updateFulfillment failed to bind parameter", 503);
    }
    return $stmt;
}

function deleteFulfillments($DB, $fulfillmentId){
    $stmt = $DB->prepare("DELETE FROM fulfillmentInformation WHERE fulfillmentId = ?");
    if(!$stmt || !$stmt->bind_param('i', $fulfillmentId)){
        return errorHandler("deleteFulfillment failed to create query", 503);
    }
    return $stmt;
}

function deleteAllFulfillmentsById($DB, $fulfillmentId){
    $stmt = $DB->prepare("DELETE FROM fulfillments WHERE fulfillmentId = ?");
    if(!$stmt || !$stmt->bind_param('i', $fulfillmentId)){
        return errorHandler("deleteAllFulfillmentsById failed to create query", 503);
    }
    return $stmt;
}

function addFulfillmentItem($DB,$fulfillmentId,$productId,$pickDate,$variety,$location,$plantsPerBox,$boxQuantity,$plantQuantity,$field,$cooler,$shed,$truck,$palletsIn,$palletsOut){
    $stmt = $DB->prepare("INSERT INTO fulfillments (fulfillmentId, productId, pickDate, variety, location, plantsPerBox,boxQuantity, plantQuantity, field, cooler, shed, truck, palletsIn, palletsOut) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    if(!$stmt || !$stmt->bind_param('iissssssssssss',$fulfillmentId,$productId,$pickDate,$variety,$location,$plantsPerBox,$boxQuantity,$plantQuantity,$field,$cooler,$shed,$truck,$palletsIn,$palletsOut)){
        return errorHandler("addFulfillmentItem failed to bind parameter", 503);
    }
    return $stmt;
}

function updateFulfillmentItem($DB,$fulfillmentItemId,$fulfillmentId,$productId,$pickDate,$variety,$location,$plantsPerBox,$boxQuantity,$plantQuantity,$field,$cooler,$shed,$truck,$palletsIn,$palletsOut){
    $stmt = $DB->prepare("UPDATE fulfillments SET fulfillmentId=?, productId=?, pickDate=?, variety=?, location=?, plantsPerBox=?,boxQuantity=?, plantQuantity=?, field=?, cooler=?, shed=?, truck=?, palletsIn=?, palletsOut=? WHERE fulfillmentItemId=?");
    if(!$stmt || !$stmt->bind_param('iissssssssssssi',$fulfillmentId,$productId,$pickDate,$variety,$location,$plantsPerBox,$boxQuantity,$plantQuantity,$field,$cooler,$shed,$truck,$palletsIn,$palletsOut,$fulfillmentItemId)){
        return errorHandler("updateFulfillmentItem failed to bind parameter", 503);
    }
    return $stmt;
}
?>