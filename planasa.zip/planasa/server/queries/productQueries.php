<?php
    function getProductList($DB){
        $stmt = $DB->prepare("SELECT productId,variety,location,plantsPerBox FROM products");
        if(!$stmt){
            return errorHandler("getProductList failed to create stmt", 503);
        }
        return $stmt;
    }

    function getProduct($DB, $productId){
        $stmt = $DB->prepare("SELECT productId,variety,location,plantsPerBox FROM products WHERE productId=?");
        if(!$stmt || !$stmt->bind_param('i', $productId)){
            return errorHandler("getProduct failed to create stmt", 503);
        }
        return $stmt;
    }

    function checkExistingProduct($DB, $variety, $location){
        $stmt = $DB->prepare("SELECT productId FROM products WHERE variety=? AND location=?");
        if(!$stmt || !$stmt->bind_param('ss', $variety, $location)){
            return errorHandler("checkExistingProduct failed to create stmt", 503);
        }
        return $stmt;
    }

    function createProduct($DB, $variety, $location, $plantsPerBox){
        $stmt = $DB->prepare("INSERT INTO products (variety, location, plantsPerBox) VALUES (?,?,?)");
        if(!$stmt || !$stmt->bind_param('ssi', $variety, $location, $plantsPerBox)){
            return errorHandler("createProduct failed to bind parameter", 503);
        }
        return $stmt;
    }

    function updateProduct($DB, $productId, $variety, $location, $plantsPerBox){
        $stmt = $DB->prepare("UPDATE products SET variety=?, location=?, plantsPerBox=? WHERE productId=?");
        if(!$stmt || !$stmt->bind_param('ssii',$variety,$location,$plantsPerBox,$productId)){
            return errorHandler("updateProduct failed to bind parameter", 503);
        }
        return $stmt;
    }

    function deleteProduct($DB, $productId){
        $stmt = $DB->prepare("DELETE FROM products WHERE productId = ?");
        if(!$stmt || !$stmt->bind_param('i', $productId)){
            return errorHandler("deleteProduct failed to create query", 503);
        }

        return $stmt;
    }
?>