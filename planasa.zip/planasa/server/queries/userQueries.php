<?php
/* ************************************************************* *\
                    USER SERVICE FUNCTIONS
\* ************************************************************* */

  function getUser($DB, $uid){
    $stmt = $DB->prepare("SELECT userId,name,email,permissions FROM users WHERE userId = ?");
    if(!$stmt->bind_param('i', $uid)){
      return errorHandler("getUsers failed to bind parameter", 503);
    }
    return $stmt;
	}

  function getUserList($DB){
    $stmt = $DB->prepare("SELECT userId,name,email FROM users");
    return $stmt;
  }

  function createUser($DB, $email, $name, $permissions, $passwordHash){
    $stmt = $DB->prepare("INSERT INTO users (name,email,password,permissions) VALUES (?,?,?,?)");

    if(!$stmt->bind_param('ssss', $name, $email, $passwordHash, $permissions)){
      return errorHandler("createUser failed to bind parameter", 503);
    }
    return $stmt;
  }

  function checkExistingUserEmail($DB, $email){
    $stmt = $DB->prepare("SELECT userId FROM users WHERE email = ?");
    if(!$stmt->bind_param('s', $email)){
      return errorHandler("checkExistingUserEmail failed to bind paramter", 503);
    }
    return $stmt;
  }

  function updateUser($DB, $uid, $email, $name, $permissions){
    $stmt = $DB->prepare("UPDATE users SET email=?, name=?, permissions=? WHERE userId=?");

    if(!$stmt->bind_param('sssi', $email, $name, $permissions, $uid)){
      return errorHandler("updateUser failed to bind parameter", 503);
    }
    return $stmt;
  }

  function deleteUser($DB, $uid){
    $stmt = $DB->prepare("DELETE FROM users WHERE userId=?");
    if(!$stmt->bind_param('i', $uid)){
      return errorHandler("deleteItem failed to bind parameter", 503);
    }
    return $stmt;
  }

/* ************************************************************* *\
                    AUTH SERVICE FUNCTIONS
\* ************************************************************* */

  function getUserByEmail($DB, $email){
    $stmt = $DB->prepare("SELECT userId,name,password,permissions FROM users WHERE email = ?");
    if(!$stmt->bind_param('s', $email)){
      return errorHandler("getUserByEmail failed to bind parameter", 503);
    }
    return $stmt;
  }

  function updateUserPassword($DB, $uid, $passwordHash){
    $stmt = $DB->prepare("UPDATE user SET userHash=? WHERE userId=?");
    
    if(!$stmt->bind_param('si', $passwordHash, $uid)){
      return errorHandler("updateUserPassword failed to bind parameter", 503);
    }
    return $stmt;
  }

  function updateUserReset($DB, $uid, $passwordHash){
    $stmt = $DB->prepare("UPDATE users SET name=? WHERE userId=?");

    if(!$stmt->bind_param('si', $passwordHash, $uid)){
      return errorHandler("updateUserReset failed to bind parameter", 503);
    }
    return $stmt;
  }
?>
