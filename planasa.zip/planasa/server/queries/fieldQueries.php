<?php
    function getFieldList($DB, $productId){
        $stmt = $DB->prepare("SELECT fieldId,fieldName,location,productId,estimatedQuantity FROM fields WHERE productId=?");
        if(!$stmt || !$stmt->bind_param('i', $productId)){
            return errorHandler("getFieldList failed to create stmt", 503);
        }
        return $stmt;
    }

    function getField($DB, $fieldId){
        $stmt = $DB->prepare("SELECT fieldId,fieldName,location,productId,estimatedQuantity FROM fields WHERE fieldId=?");
        if(!$stmt || !$stmt->bind_param('i', $fieldId)){
            return errorHandler("getField failed to create stmt", 503);
        }
        return $stmt;
    }

    function checkExistingField($DB, $fieldName, $location, $productId){
        $stmt = $DB->prepare("SELECT fieldId FROM fields WHERE fieldName=? AND location=? AND productId=?");
        if(!$stmt || !$stmt->bind_param('ssi', $fieldName, $location, $productId)){
            return errorHandler("checkExistingField failed to create stmt", 503);
        }
        return $stmt;
    }

    function createField($DB, $fieldName, $location, $productId, $estimatedQuantity){
        $stmt = $DB->prepare("INSERT INTO fields (fieldName, location, productId, estimatedQuantity) VALUES (?,?,?,?)");
        if(!$stmt || !$stmt->bind_param('ssii', $fieldName, $location, $productId, $estimatedQuantity)){
            return errorHandler("createField failed to bind parameter", 503);
        }
        return $stmt;
    }

    function updateField($DB, $fieldId, $fieldName, $location, $productId, $estimatedQuantity){
        $stmt = $DB->prepare("UPDATE fields SET fieldName=?, location=?, productId=?, estimatedQuantity=? WHERE fieldId=?");
        if(!$stmt || !$stmt->bind_param('ssiii',$fieldName,$location,$productId,$estimatedQuantity,$fieldId)){
            return errorHandler("updateField failed to bind parameter", 503);
        }
        return $stmt;
    }

    function deleteField($DB, $fieldId){
        $stmt = $DB->prepare("DELETE FROM fields WHERE fieldId = ?");
        if(!$stmt || !$stmt->bind_param('i', $fieldId)){
            return errorHandler("deleteField failed to create query", 503);
        }

        return $stmt;
    }
?>