<?php
function getOrdersByGrower($DB, $season, $growerId){
    $query = 'SELECT a.orderId, a.orderProductId, a.location, a.variety, a.plantQuantity, c.prorate, b.growerName, b.growerId, b.season, b.orderNumber FROM `orders` AS a ';
    $query.= 'LEFT JOIN orderInformation AS b ON a.orderId = b.orderId ';
    $query.= 'LEFT JOIN prorate AS c ON a.location = c.location AND a.variety = c.variety ';
    $query.= 'WHERE b.season = ? AND b.growerId = ?';

    $stmt = $DB->prepare($query);
    if(!$stmt || !$stmt->bind_param('ss',$season, $growerId)){
        return errorHandler("getOrdersByGrower failed to create stmt", 503);
    }
    return $stmt;
}
function getFulfillmentsByGrower($DB, $season, $growerId){
    $query = 'SELECT a.fulfillmentId, a.fulfillmentItemId, a.location, a.variety, a.plantQuantity, b.orderId, b.season, b.notes FROM `fulfillments` AS a ';
    $query.= 'LEFT JOIN fulfillmentInformation AS b ON a.fulfillmentId = b.fulfillmentId ';
    $query.= 'LEFT JOIN orderInformation AS c on b.orderId = c.orderId ';
    $query.= 'WHERE b.season = ? AND c.growerId = ? ';

    $stmt = $DB->prepare($query);
    if(!$stmt || !$stmt->bind_param('ss', $season, $growerId)){
        return errorHandler("getFulfillmentsByGrower failed to create stmt", 503);
    }
    return $stmt;
}



function getOrdersByVariety($DB, $season, $variety, $location){
    $query = 'SELECT a.orderId, a.orderProductId, a.plantQuantity, b.growerName, b.growerId, b.season, b.orderNumber FROM `orders` AS a ';
    $query.= 'LEFT JOIN orderInformation AS b ON a.orderId = b.orderId ';
    $query.= 'WHERE b.season = ? AND a.variety = ? AND a.location = ?';

    $stmt = $DB->prepare($query);
    if(!$stmt || !$stmt->bind_param('sss',$season, $variety, $location)){
        return errorHandler("getOrdersByVariety failed to create stmt", 503);
    }
    return $stmt;
}

function getFulfillmentsByVariety($DB, $season, $variety, $location){
    $query = 'SELECT a.fulfillmentId, a.fulfillmentItemId, a.plantQuantity, b.orderId, b.season, b.notes FROM `fulfillments` AS a ';
    $query.= 'LEFT JOIN fulfillmentInformation AS b ON a.fulfillmentId = b.fulfillmentId ';
    $query.= 'WHERE b.season = ? AND a.variety = ? AND a.location = ?';

    $stmt = $DB->prepare($query);
    if(!$stmt || !$stmt->bind_param('sss', $season, $variety, $location)){
        return errorHandler("getFulfillmentsByVariety failed to create stmt", 503);
    }
    return $stmt;
}

function getOrdersByVarietyAndGrower($DB, $season, $variety, $location){
    $query = 'SELECT b.growerId, b.growerName, g.clubName, SUM(a.plantQuantity) AS plantQuantity FROM orders AS a ';
    $query.= 'LEFT JOIN orderInformation AS b ON a.orderId = b.orderId ';
    $query.= 'LEFT JOIN growers AS g ON g.growerId = b.growerId ';
    $query.= 'WHERE b.season = ? AND a.variety = ? AND a.location = ? ';
    $query.= 'GROUP BY b.growerId ';

    $stmt = $DB->prepare($query);
    if(!$stmt || !$stmt->bind_param('sss',$season, $variety, $location)){
        return errorHandler("getOrdersByVarietyAndGrower failed to create stmt", 503);
    }
    return $stmt;
}

function getFulfillmentsByVarietyAndGrower($DB, $season, $variety, $location){
    $query = 'SELECT c.growerId, SUM(a.plantQuantity) AS plantQuantity FROM `fulfillments` AS a ';
    $query.= 'LEFT JOIN fulfillmentInformation AS b ON a.fulfillmentId = b.fulfillmentId ';
    $query.= 'LEFT JOIN orderInformation AS c ON c.orderId = b.orderId ';
    $query.= 'WHERE b.season = ? AND a.variety = ? AND a.location = ? ';
    $query.= 'GROUP BY c.growerId ';

    $stmt = $DB->prepare($query);
    if(!$stmt || !$stmt->bind_param('sss', $season, $variety, $location)){
        return errorHandler("getFulfillmentsByVarietyAndGrower failed to create stmt", 503);
    }
    return $stmt;
}




?>