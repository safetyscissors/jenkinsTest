<?php
function getOrderList($DB, $season){
    $stmt = $DB->prepare("SELECT orderId,orderNumber,orderDate,deliveryDate,season,orderInformation.notes,orderInformation.status,growers.countyShort,growerName,variety,location,plantsPerBox,boxQuantity,plantQuantity FROM orderInformation LEFT JOIN growers ON growers.growerId = orderInformation.growerId WHERE season=?");
    if(!$stmt || !$stmt->bind_param('s', $season)){
        return errorHandler("getOrderList failed to create stmt", 503);
    }
    return $stmt;
}

function getDetailedOrderList($DB, $season){
    $orderInfoFields = "a.orderId, a.orderNumber, a.orderDate, a.season, a.notes, a.status, a.growerName";
    $growerFields = "g.countyShort";
    $orderFields = "b.variety, b.location, b.plantQuantity";

    $sql = "SELECT $orderInfoFields, $growerFields, $orderFields FROM orderInformation AS a ";
    $sql.= "LEFT JOIN growers AS g ON g.growerId = a.growerId ";
    $sql.= "LEFT JOIN orders AS b ON b.orderId = a.orderId ";
    $sql.= "WHERE a.season = ? ";
    $sql.= "ORDER BY a.orderId DESC LIMIT 1000";
    $stmt = $DB->prepare($sql);
    if(!$stmt || !$stmt->bind_param('s', $season)){
        return errorHandler("getDetailedOrderList failed to create stmt", 503);
    }
    return $stmt;
}


function searchDetailedOrderList($DB,$season,$searchTerms,$status){
    $whereClause = "";
    $searchFields = array("a.orderNumber", "a.orderDate", "a.notes", "a.status", "a.growerName", "g.countyShort", "b.variety", "b.location", "b.plantQuantity");
    if(count($searchTerms)>0){
        $whereClause = "WHERE ";
        $andJoins = array();

        for($i=0;$i<count($searchTerms);$i++){
            $orJoins = array();
            $searchTerm = $DB->real_escape_string($searchTerms[$i]);
            $searchTerm = ' LIKE "%'.$searchTerm.'%"';
            for($j=0;$j<count($searchFields);$j++){
                array_push($orJoins,$searchFields[$j].$searchTerm);
            }
            $andJoins[$i] = "(".implode(' OR ',$orJoins).")";
        }
        if($status && $status != 'all') array_push($andJoins,'a.status = "'.$status.'"');
        array_push($andJoins, 'a.season = "'.$season.'"');
        $whereClause.= implode(' AND ',$andJoins);
    }else{
        $whereClause = "WHERE a.season=$season";
    }

    $orderInfoFields = "a.orderId, a.orderNumber, a.orderDate, a.season, a.notes, a.status, a.growerName";
    $growerFields = "g.countyShort";
    $orderFields = "b.variety, b.location, b.plantQuantity";

    $sql = "SELECT $orderInfoFields, $growerFields, $orderFields FROM orderInformation AS a ";
    $sql.= "LEFT JOIN growers AS g ON g.growerId = a.growerId ";
    $sql.= "LEFT JOIN orders AS b ON b.orderId = a.orderId ";
    $sql.= "$whereClause ";
    $sql.= "ORDER BY a.orderId DESC LIMIT 1000";

    $stmt = $DB->prepare($sql);
    if(!$stmt){
        return errorHandler("getDetailedOrderList failed to create stmt", 503);
    }
    return $stmt;
}

function getOrderProducts($DB, $orderId){
    $stmt = $DB->prepare("SELECT orderProductId,variety,location,boxQuantity,plantsPerBox,plantQuantity FROM orders WHERE orderId=?");
    if(!$stmt || !$stmt->bind_param('i', $orderId)){
        return errorHandler("getOrderProducts failed to create stmt", 503);
    }
    return $stmt;
}

function checkExistingOrder($DB, $deliveryDate, $growerId, $variety, $location, $boxQuantity){
    $stmt = $DB->prepare("SELECT orderId FROM orderInformation WHERE deliveryDate=? AND growerId=? AND variety=? AND location=? AND boxQuantity=?");
    if(!$stmt || !$stmt->bind_param('sissi', $deliveryDate, $growerId, $variety, $location, $boxQuantity)){
        return errorHandler("checkExistingOrder failed to create stmt", 503);
    }
    return $stmt;
}

function createOrder($DB, $orderNumber, $orderDate, $deliveryDate, $season, $notes, $growerId, $growerName, $variety, $location, $plantsPerBox, $boxQuantity){
    $stmt = $DB->prepare("INSERT INTO orderInformation (orderNumber,orderDate,deliveryDate,season,notes,growerId,growerName,variety,location,plantsPerBox,boxQuantity) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
    if(!$stmt || !$stmt->bind_param('sssssisssii', $orderNumber, $orderDate, $deliveryDate, $season, $notes, $growerId, $growerName, $variety,$location, $plantsPerBox, $boxQuantity)){
        return errorHandler("createOrder failed to bind parameter", 503);
    }
    return $stmt;
}

function initAddOrderProducts($DB){
    $stmt = $DB->prepare("INSERT INTO orders (orderId, variety, location, boxQuantity, plantsPerBox, plantQuantity) VALUES(?,?,?,?,?,?)");
    return $stmt;
}

function getOrder($DB, $orderId){
    $stmt = $DB->prepare("SELECT orderId,orderNumber,orderDate,deliveryDate,season,notes,status,growerId,growerName,variety,location,plantsPerBox,boxQuantity FROM orderInformation WHERE orderId=?");
    if(!$stmt || !$stmt->bind_param('i', $orderId)){
        return errorHandler("getOrder failed to create stmt", 503);
    }
    return $stmt;
}

function updateOrder($DB, $orderId, $orderNumber, $orderDate, $deliveryDate, $season, $notes, $status, $growerId, $growerName, $variety, $location, $plantsPerBox, $boxQuantity){
    $stmt = $DB->prepare("UPDATE orderInformation SET orderNumber=?,orderDate=?,deliveryDate=?,season=?,notes=?,status=?,growerId=?,growerName=?,variety=?,location=?,plantsPerBox=?,boxQuantity=? WHERE orderId=?");
    if(!$stmt || !$stmt->bind_param('ssssssisssiii', $orderNumber, $orderDate, $deliveryDate, $season, $notes, $status, $growerId, $growerName, $variety,$location, $plantsPerBox, $boxQuantity, $orderId)){
        return errorHandler("updateOrder failed to bind parameter", 503);
    }
    return $stmt;
}

function updateOrderProduct($DB,$productId,$variety,$location,$boxQuantity,$plantsPerBox,$plantQuantity){
    $stmt = $DB->prepare("UPDATE orders SET variety=?,location=?,boxQuantity=?,plantsPerBox=?,plantQuantity=? WHERE orderProductId=?");
    if(!$stmt || !$stmt->bind_param('sssssi',$variety,$location,$boxQuantity,$plantsPerBox,$plantQuantity,$productId)){
        return errorHandler("updateOrderProduct failed to bind parameter", 503);
    }
    return $stmt;
}

function deleteOrder($DB, $orderId){
    $stmt = $DB->prepare("DELETE FROM orderInformation WHERE orderId = ?");
    if(!$stmt || !$stmt->bind_param('i', $orderId)){
        return errorHandler("deleteOrder failed to create query", 503);
    }
    return $stmt;
}

function deleteAllOrdersByOrderId($DB, $orderId){
    $stmt = $DB->prepare("DELETE FROM orders WHERE orderId = ?");
    if(!$stmt || !$stmt->bind_param('i', $orderId)){
        return errorHandler("deleteAllOrdersByOrderId failed to create query", 503);
    }
    return $stmt;
}

function saveOrderNumber($DB, $orderId, $orderNumber){
    $stmt = $DB->prepare("UPDATE orderInformation SET orderNumber=? WHERE orderId=?");
    if(!$stmt || !$stmt->bind_param('si',$orderNumber, $orderId)){
        return errorHandler("saveOrderNumber failed to bind parameter", 503);
    }
    return $stmt;
}

function deleteOrderProduct($DB, $orderProductId){
    $stmt = $DB->prepare("DELETE FROM orders WHERE orderProductId = ?");
    if(!$stmt || !$stmt->bind_param('i', $orderProductId)){
        return errorHandler("deleteOrderProduct failed to create query", 503);
    }
    return $stmt;
}
?>