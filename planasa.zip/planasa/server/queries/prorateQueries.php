<?php
    function checkProrateExists($DB, $season, $variety, $location){
        $stmt = $DB->prepare("SELECT prorateId FROM prorate WHERE season=? AND variety=? AND location=?");
        if(!$stmt || !$stmt->bind_param('sss', $season, $variety, $location)){
            return errorHandler("checkProrateExists failed to create stmt", 503);
        }
        return $stmt;
    }
    function insertProrate($DB, $prorate, $season, $variety, $location){
        $stmt = $DB->prepare("INSERT INTO prorate (prorate, season, variety, location) VALUES (?,?,?,?)");
        if(!$stmt || !$stmt->bind_param('ssss', $prorate, $season, $variety, $location)){
            return errorHandler("insertProrate failed to create stmt", 503);
        }
        return $stmt;
    }
    function updateProrate($DB, $prorate, $prorateId){
        $stmt = $DB->prepare("UPDATE prorate SET prorate=? WHERE prorateId=?");
        if(!$stmt || !$stmt->bind_param('si', $prorate, $prorateId)){
            return errorHandler("updateProrate failed to create stmt", 503);
        }
        return $stmt;
    }
    function getProrate($DB, $season, $variety, $location){
        $stmt = $DB->prepare("SELECT prorate FROM prorate WHERE season=? AND variety=? AND location=?");
        if(!$stmt || !$stmt->bind_param('sss', $season, $variety, $location)){
            return errorHandler("getProrate failed to create stmt", 503);
        }
        return $stmt;
    }
?>