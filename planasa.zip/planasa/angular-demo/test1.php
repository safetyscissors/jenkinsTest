<!DOCTYPE html>
<html ng-app="demo">
<head lang="en">
    <meta charset="utf-8">
    <title>angular demo</title>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.7/angular.min.js"></script>
    <style>
        .done{
            text-decoration:line-through;
            color:grey;
        }
    </style>
</head>
<body>
    <div ng-controller="todoController">
        <form name="todoForm" ng-submit="addItem()">
            <input type="text" name="newTodo" ng-model="newTodo" required>
            <button ng-disabled="form.$invalid">Go</button>
        </form>
        <button ng-click="cleanList()">clear completed</button>

        <ul>
            <li ng-repeat="todo in todos">
                <input type="checkbox" ng-model="todo.done">
                <span ng-class="{done:todo.done}" ng-class="done">{{todo.title}}</span>
            </li>
        </ul>
    </div>

    <script type="text/javascript">
        angular.module('demo',[]).controller('todoController',['$scope',function($scope){
            $scope.todos = [
                {title:'Build a todo', done:false}
            ]

            $scope.addItem = function(){
                $scope.todos.push({title:$scope.newTodo, done:false});
                $scope.newTodo="";
            };
            $scope.cleanList = function(){
                $scope.todos = $scope.todos.filter(function(item){ return !item.done });
            };
        }]);
    </script>
</body>
</html>
