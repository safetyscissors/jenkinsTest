angular.module('phoneList').component('phoneList',
    {
        templateUrl: 'phone-list/phonelist.template.html',
        controller: function($http){
            var _this = this;

            _this.orderProp = 'age';

            $http.get('phone-list/phones.json').then(function(response) {
                _this.phones = response.data;
            });


        }

    });