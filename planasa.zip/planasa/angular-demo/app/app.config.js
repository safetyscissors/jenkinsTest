angular.
module('planasa').
config(['$locationProvider', '$routeProvider',
    function config($locationProvider, $routeProvider) {
        $locationProvider.hashPrefix('!');

        $routeProvider.
        when('/phones', {
            template: '<phone-list></phone-list>'
        }).
        when('/phones/:phoneId', {
            template: '<phone-detail></phone-detail>'
        })

        .when('/',                              { template: '<dashboard></dashboard>' })
        .when('/client/',                       { template: '<client-list></client-list>' })
        .when('/client/:clientId',              { template: '<client-list></client-list>' })
//        .when('/client/:clientId',              { template: '<client-detail></client-detail>' })
        .when('/orders/',                       { template: '<order-list></order-list>' })
        .when('/orders/:orderId',               { template: '<order-detail></order-detail>' })
        .when('/orders/client/:clientId',       { template: '<client-order-list></client-order-list>' })
        .when('/fulfillment/',                  { template: '<fulfillment-list></fulfillment-list>' })
        .when('/fulfillment/:fulfillmentId',    { template: '<fulfillment-detail></fulfillment-detail>' })
        .when('/fulfillment/order/:orderId',    { template: '<order-fulfillment-list></order-fulfillment-list>' })
        .when('/fulfillment/client:clientId',   { template: '<client-fulfillment-list></client-fulfillment-list>' })
        .when('/products/',                     { template: '<products></products>'})
        .when('/products/:productId',           { template: '<products></products>'})
        .when('/report/',                       { template: '<report></report>'})
        .when('/login/',                       { template: '<login></login>'})
        .otherwise('/');

    }
]);