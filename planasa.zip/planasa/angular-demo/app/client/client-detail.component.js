angular.module('clientDetail').component('clientDetail',
    {
        templateUrl: 'client/client-detail.template.html',
        controller: function($routeParams){
            this.clientId = $routeParams['clientId'];
        }
    });