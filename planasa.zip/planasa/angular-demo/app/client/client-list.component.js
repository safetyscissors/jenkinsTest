angular.module('clientList').component('clientList',
    {
        templateUrl: 'client/user-list.template.html',
        controller: function($routeParams, $http, $scope){
            var _this = this;
            _this.clientId = $routeParams['clientId'];

            $scope.setSelected = function(e){
                $scope.selected=e;
                //angular.element( document.querySelector(divId)).addClass('selected');
            };

            $http.get('client/client.json').then(function(response) {
                _this.clients = response.data;
                for(var i=0;i<_this.clients.length;i++){
                    if(_this.clients[i].clientId == _this.clientId){
                        $scope.selected = _this.clients[i];
                    }
                }
            });

        }
    });