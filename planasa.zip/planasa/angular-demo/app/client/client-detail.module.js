angular.module('clientDetail', []);
