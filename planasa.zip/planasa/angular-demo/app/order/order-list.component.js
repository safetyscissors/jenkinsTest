angular.module('orderList').component('orderList',
    {
        templateUrl: 'order/order-list.template.html',
        controller: function($routeParams, $http, $scope, $location){
            var _this = this;

            $scope.detail = function(order){
                $location.url('orders/'+order.orderId);
                console.log('going to', order.orderId);
            };

            $http.get('order/order.json').then(function(response) {
                _this.orders = response.data;

                for(var i=0;i<_this.orders.length;i++){
                    var notes = _this.orders[i]['notes'];
                    if(notes) {
                        notes = notes.split('\n');
                        var continuation = (notes.length > 1 || notes[0].length > 20)? '...' : '';
                        _this.orders[i]['preview'] = notes[0].substr(0,20) + continuation;
                    }
                }
            });

        }
    });