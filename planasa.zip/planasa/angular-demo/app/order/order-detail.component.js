angular.module('orderDetail').component('orderDetail',
    {
        templateUrl: 'order/order-detail.template.html',
        controller: function($routeParams, $http, $scope){
            var _this = this;

            _this.orderId = $routeParams['orderId'];

            $http.get('order/order.json').then(function(response) {

                for(var i=0;i<response.data.length;i++){
                    if(response.data[i]['orderId'] == _this.orderId) _this.order = response.data[i];
                }
            });
        }
    });