angular.module('clientOrderList').component('clientOrderList',
    {
        templateUrl: 'order/client-order-list.template.html',
        controller: function($routeParams){
            this.clientId = $routeParams['clientId'];
        }
    });