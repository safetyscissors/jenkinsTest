angular.module('report').component('report',
    {
        templateUrl: 'reports/report.template.html',
        controller: function($routeParams, $http, $scope){
            var _this = this;

            $http.get('reports/report.json').then(function(response) {
                _this.report = response.data;
            });
        }
    });