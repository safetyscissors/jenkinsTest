angular.module('fulfillmentList').component('fulfillmentList',
    {
        templateUrl: 'fulfillment/fulfillment-list.template.html',
        controller: function($routeParams, $http, $scope, $location){
            var _this = this;

            $scope.detail = function(fulfillment){
                $location.url('orders/'+fulfillment.order.orderId);
                console.log('going to', fulfillment.fulfillmentId);
            };

            $http.get('fulfillment/fulfillment.json').then(function(response) {
                _this.fulfillments = response.data;

                for(var i=0;i<_this.fulfillments.length;i++){
                    var notes = _this.fulfillments[i]['notes'];
                    if(notes) {
                        notes = notes.split('\n');
                        var continuation = (notes.length > 1 || notes[0].length > 20)? '...' : '';
                        _this.fulfillments[i]['preview'] = notes[0].substr(0,20) + continuation;
                    }
                }
            });

        }
    });