angular.module('clientFulfillmentList').component('clientFulfillmentList',
    {
        templateUrl: 'fulfillment/client-fulfillment-list.template.html',
        controller: function($routeParams){
            this.clientId = $routeParams['clientId'];
        }
    });