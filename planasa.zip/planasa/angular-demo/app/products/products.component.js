angular.module('products').component('products',
    {
        templateUrl: 'products/products.template.html',
        controller: function($routeParams, $http, $scope){
            var _this = this;
            _this.productId = $routeParams['productId'];

            $scope.setSelected = function(e){
                $scope.selected=e;
                //angular.element( document.querySelector(divId)).addClass('selected');
            };

            $http.get('products/products.json').then(function(response) {
                _this.products = response.data;
                if(!_this.productId){
                    $scope.selected = _this.products[0];
                }else{
                    for(var i=0;i<_this.products.length;i++){
                        if(_this.products[i].productId == _this.productId){
                            $scope.selected = _this.products[i];
                        }
                    }
                }
            });

        }
    });