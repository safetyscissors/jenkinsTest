angular.module('phoneDetail').component('phoneDetail', {
    templateUrl:'phone-detail/phone-detail.template.html',
    controller: function($routeParams) {
        this.phoneId = $routeParams['phoneId'];
    }
});