angular.module('phoneDetail', []);
