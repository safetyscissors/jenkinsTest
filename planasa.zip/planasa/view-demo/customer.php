<script type="text/javascript" src="dailyReportData.js"></script>
<script type="text/javascript" src="tableFunctions.js"></script>
<script type="text/javascript" src="customerData.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        var dailyDataFields = ['variety','order','delivered','prorated','balance'];
        addTableRecord(dailyDataHeader, dailyDataFields, 'report');
        if(dailyFarmData){
            for(var i=0;i<dailyFarmData.length;i++) {
                addTableRecord(dailyFarmData[i], dailyDataFields, 'report');
            }
        }

        var deliveryDataFields = ['deliverydate','deliverynumber','boxes','plants','variety','orderdate','field','shed','truck','cooler'];
        addTableRecord(deliveryTicketHeader, deliveryDataFields, 'transactions');
        if(deliveryTicketData){
            for(var i=0;i<deliveryTicketData.length;i++) {
                addTableRecord(deliveryTicketData[i], deliveryDataFields, 'transactions');
            }
        }
    });
</script>


<div class="row">
    <div class="titleBox col-md-offset-1 col-md-10">
        <h1 style="float:left; margin-right:20px">Leslie Farms Transactions</h1>
        <div style="margin-top:20px; float:right">
            <input class="form-control" style="width:200px; margin-right:5px; float:left" type="combo" value="Leslie Farms"> <button type="button" class="btn btn-primary"> > </button>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-offset-1 col-md-10">
        <table id="report" class="table table-hover">
            <tbody>
            </tbody>
        </table>
    </div>
</div>
<div class="row">
    <div class="titleBox col-md-offset-1 col-md-10">
        <h1 style="">Delivery Tickets</h1>
    </div>
</div>
<div class="row">
    <div class="col-md-offset-1 col-md-10">
        <table id="transactions" class="table table-hover">
            <tbody>
            </tbody>
        </table>
    </div>
</div>