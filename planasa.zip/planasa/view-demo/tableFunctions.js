function addTableRecord(farm, fields, tableId, hasModifier){
    var classes = (farm.totalRow)? ' class="totalRow"' : '';
    var rowId = (farm.id)? ' id="'+farm.id+'"' : '';
    var tds = ['<tr'+classes+rowId+' >'];
    var cell = (farm.header)? 'th':'td';
    for(var i=0;i<fields.length;i++){
        var key = (fields[i]).toLowerCase();
        var value = farm[key];
        if(cell == 'th' && value!='') value += '<span class="caret"></span>';
        if(!value) value = '';
        var modifier = (hasModifier && (key=='order' || key=='delivered'))? ' text-right':'';
        tds.push('<'+cell+' class="'+key+modifier+'">'+value+'</'+cell+'>');
    }
    tds.push('</tr>');
    var html = tds.join('\n');
    $('#'+tableId+'>tbody').append(html);
}

function clearTableData(tableId){
   $('#'+tableId+'>tbody').html('');
}