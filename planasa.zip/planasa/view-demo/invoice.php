<script type="text/javascript" src="invoiceData.js"></script>
<script type="text/javascript" src="tableFunctions.js"></script>

<script type="text/javascript">
    function totalInvoiceRows(data){
        var totalObj = {
            totalRow:true,
            variety:'Total',
            rate:data[0]['rate'],
            boxes:0,
            plants:0
        };
        for(var i=0;i<data.length;i++){
            totalObj.boxes += Number(data[i]['boxes']);
            totalObj.plants += Number(data[i]['plants']);
            if(data[i]['rate']!=totalObj.rate) totalObj.rate === '';
        }
        return totalObj;
    }

    $(document).ready(function() {
        var invoiceDataFields = ['variety','boxes', 'rate', 'plants'];
        addTableRecord(invoiceHeader, invoiceDataFields, 'order');
        if(invoiceData){
            for(var i=0;i<invoiceData.length;i++) {
                addTableRecord(invoiceData[i], invoiceDataFields, 'order');
            }
        }
        addTableRecord(totalInvoiceRows(invoiceData), invoiceDataFields, 'order');
    });

</script>


<div class="row">
    <div class="titleBox col-md-offset-1 col-md-10">
        <h1 style="float:left; margin-right:20px">Delivery Number: 20523027<br><small><span class="headerDateBox">10/25/05</span> Chino Nojo</small></h1>
        <div style="margin-top:20px; float:right">
            <input class="form-control" style="width:200px; margin-right:5px; float:left" type="combo" value="20523027"> <button type="button" class="btn btn-primary"> > </button>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-offset-1 col-md-6">
        <table id="order" class="table table-hover">
            <tbody></tbody>
        </table>
    </div>
    <div class="col-md-4 invoiceBox">
        <strong style="font-size:1.5em">Pallets</strong><br>
        0 out | 0 returned
    </div>
    <div class="col-md-4 invoiceBox">
        <strong style="font-size:1.5em">Notes</strong><br>
        via Randy Ito
    </div>
</div>