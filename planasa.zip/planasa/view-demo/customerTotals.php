<script type="text/javascript" src="customerTotalData.js"></script>
<script type="text/javascript" src="tableFunctions.js"></script>
<script type="text/javascript">
    function createSummaryData(raw){
        var summaryData = [];

        for(var i=0;i<raw.length;i++){
            var customer = summaryData[raw[i]['name']];
            if(typeof customer === 'object'){
                summaryData[raw[i]['name']]['count'] +=1;
                summaryData[raw[i]['name']]['endrange'] = (raw[i]['deliverydate']).substr(0,5);
                summaryData[raw[i]['name']]['daterange'] = summaryData[raw[i]['name']]['startrange'] + ' - ' + summaryData[raw[i]['name']]['endrange']
            }
            else{
                summaryData[raw[i]['name']] = {
                    name:raw[i]['name'],
                    id:raw[i]['farmid'],
                    count:1,
                    startrange:(raw[i]['deliverydate']).substr(0,5),
                    daterange:(raw[i]['deliverydate']).substr(0,5)
                }
            }
        }

        return summaryData;

    }
    function selectFarm(farmId, raw){
        clearTableData('customerData');
        addTableRecord(customerListDataHeader, customerSummaryFields, 'customerData');

        $('.success').removeClass('success');
        $('#'+farmId).addClass('success');

        var farmData = [];
        var farmName = null;
        for(var i=0;i<raw.length;i++){
            if(raw[i]['farmid'] == farmId){
                var invoice = raw[i];
                if(!farmName) farmName = invoice.name;
                invoice.deliverynumber = '<a href="../view-demo/?page=invoice">'+invoice.deliverynumber+'</a>';
                addTableRecord(invoice, customerSummaryFields, 'customerData');
            }
        }

        if(farmName) {
            $('#selectedCustomerName').html(farmName);
            $('#selectedCustomerSearch').val(farmName);

        }
    }

    var customerListFields = ['name','count','daterange'];
    var customerSummaryFields = ['deliverynumber','boxes','plants','variety','orderdate','field','shed','cooler','notes'];
    $(document).on('click','#customerList tr', function(){
        selectFarm(this.id, customerListData);
    });
    $(document).ready(function() {
        addTableRecord(customerListHeader, customerListFields, 'customerList');
        var summaryData = createSummaryData(customerListData);
        if(summaryData){
            for(var key in summaryData){
                addTableRecord(summaryData[key], customerListFields, 'customerList');
            }
        }

        selectFarm(1, customerListData);
    });
</script>

<div class="row">
    <div class="titleBox col-md-offset-1 col-md-3">
        <h1 style="float:left; margin-right:20px">Customer List</h1>
    </div>
    <div class="titleBox col-md-7">
        <h1 id="selectedCustomerName" style="float:left; margin-right:20px"></h1>
        <div style="margin-top:20px; float:right">
            <input id="selectedCustomerSearch" class="form-control" style="width:200px; margin-right:5px; float:left" type="combo" value=""> <button type="button" class="btn btn-primary"> > </button>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-offset-1 col-md-3">
        <table id="customerList" class="table table-hover">
            <tbody>
            </tbody>
        </table>
    </div>
    <div class="col-md-7">
        <table id="customerData" class="table table-hover">
            <tbody>
            </tbody>
        </table>
    </div>
</div>