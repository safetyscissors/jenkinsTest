var dailyDataHeader = {
    customer:'Variety',
    variety:'Variety',
    order:'Order',
    orderpercent:'',
    delivered:'Delivered',
    deliveredpercent:'',
    balance:'Balance',
    over:'Over',
    prorated:'ProRated',
    header:true
};
var dailySummaryData = [
    {
        customer:'Albion',
        order:'95,741,000',
        orderpercent:'91%',
        delivered:'86,940,500',
        deliveredpercent:'110%',
        balance:'-5,841,800',
        over:'13,739,600',
        prorated:'79,042,700',
        tableHeader:true
    },
    {

        customer:'MacDoel',
        order:'83,491,500',
        orderpercent:'79%',
        delivered:'66,270,000',
        deliveredpercent:'99%',
        balance:'-5,838,800',
        over:'5,315,600',
        prorated:'66,793,200',
        tableHeader:true
    }];
var dailyFarmData = [
    {
        id:'a165',
        area:'MacDoel',
        variety:'Camarosa',
        customer:'A&A Farms/NATURIPE',
        order:'472,500',
        orderpercent:'76%',
        delivered:'360,000',
        deliveredpercent:'95%',
        balance:'-18,000',
        over:'',
        prorated:'378,000'
    },
    {
        id:'B430',
        area:'MacDoel',
        variety:'Camino Real',
        customer:'Berry Sweet Farms/CROWN J',
        order:'1,500,00',
        orderpercent:'78%',
        delivered:'1,170,000',
        deliveredpercent:'98%',
        balance:'-30,000',
        over:'',
        prorated:'1,200,000'
    },
    {
        id:'b550',
        area:'MacDoel',
        variety:'Ventana',
        customer:'Berry Valley/NATURIPE',
        order:'1,150,500',
        orderpercent:'82%',
        delivered:'945,000',
        deliveredpercent:'103%',
        balance:'',
        over:'24,600',
        prorated:'920,400'
    }];
