var deliveryTicketHeader = {
    deliverydate:'Delivery Date',
    deliverynumber:'Delivery Number',
    boxes:'Boxes',
    plants:'Plants',
    variety:'Variety',
    orderdate:'Order Date',
    field:'Field',
    shed:'Shed',
    truck:'Truck',
    cooler:'Cooler',
    header:true
};
var deliveryTicketData = [
    {
        deliverydate:'9/30/04',
        deliverynumber:'2043004',
        boxes:'320',
        plants:'480000',
        variety:'Camerosa',
        orderdate:'9/27/04',
        field:'lcn4',
        shed:'mt',
        truck:'11',
        cooler:'Guimarra Cooler'
    },
    {
        deliverydate:'10/3/04',
        deliverynumber:'2043011',
        boxes:'256',
        plants:'384000',
        variety:'Camerosa',
        orderdate:'10/1/04',
        field:'lcn4',
        shed:'rd',
        truck:'39',
        cooler:'Guimarra Cooler'
    }
]