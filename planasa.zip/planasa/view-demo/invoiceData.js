var invoiceHeader = {
    boxes:'Boxes',
    rate:'Plants/Box',
    plants:'Quantity',
    variety:'Variety',
    header:true
};
var invoiceData = [{
        boxes:'5',
        rate:'1500',
        plants:'7500',
        variety:'MacDoel Albion'
    },
    {
        boxes:'1',
        rate:'1500',
        plants:'1500',
        variety:'MacDoel Camino Real'
    },
    {
        boxes:'1',
        rate:'1500',
        plants:'1500',
        variety:'MacDoel Chandler'
    },
    {
        boxes:'1',
        rate:'1500',
        plants:'1500',
        variety:'MacDoel Gaviota'
    }];