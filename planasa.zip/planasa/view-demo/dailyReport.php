<script type="text/javascript" src="dailyReportData.js"></script>
<script type="text/javascript" src="tableFunctions.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        var dailyDataFields = ['customer','order','orderpercent','delivered','deliveredpercent','balance','over','prorated'];
        addTableRecord(dailyDataHeader, dailyDataFields, 'report', true);
        if(dailySummaryData){
            for(var j=0;j<dailySummaryData.length;j++){
                addTableRecord(dailySummaryData[j], dailyDataFields, 'report', true);
            }
        }

        dailyDataHeader.customer = 'Customer';
        addTableRecord(dailyDataHeader, dailyDataFields, 'report', true);

        if(dailyFarmData){
            for(var i=0;i<dailyFarmData.length;i++) {
                addTableRecord(dailyFarmData[i], dailyDataFields, 'report', true);
            }
        }
    });
</script>

<div class="row">
    <div class="titleBox col-md-offset-1 col-md-10">
        <h1 style="float:left; margin-right:20px">Daily Report</h1>
        <div style="margin-top:20px; float:right">
            <input class="form-control" style="width:200px; margin-right:5px; float:left" type="combo" value="Albion > MacDoel"> <button type="button" class="btn btn-primary"> > </button>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-offset-1 col-md-10">
        <table id="report" class="table table-hover">
            <tbody>
            </tbody>
        </table>
    </div>
</div>

