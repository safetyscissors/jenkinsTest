<html>
<head>
    <?php include('header.php');?>
</head>
<body>
    <?php include('menu.php'); ?>
    <div id="container-fluid">
        <?php
            if(!isset($_GET['page'])){
                echo 'no page';
                return;
            }
            switch($_GET['page']){
                case 'customer': include('customer.php');
                    break;
                case 'daily': include('dailyReport.php');
                    break;
                case 'invoice': include('invoice.php');
                    break;
                case 'customerTotals': include('customerTotals.php');
                    break;
                default: echo 'no page '.$_GET['page'];
            }
        ?>
    </div>
</body>
</html>

