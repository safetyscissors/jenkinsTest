<link href="bootstrap/css/bootstrap.css" rel="stylesheet" />
<link href="structure.css" rel="stylesheet" />
<script type="text/javascript" src="jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript">
</script>