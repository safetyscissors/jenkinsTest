<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="bootstrap.min.css" type="text/css" rel="stylesheet">
    <script   src="https://code.jquery.com/jquery-3.1.0.min.js"   integrity="sha256-cCueBR6CsyA4/9szpPfrX3s49M9vUU5BgtiJj06wt/s="   crossorigin="anonymous"></script>

</head>
<body>
<div class="container-fluid" style="margin:15px; overflow:hidden">
    <div class="row">
        <div class="col-md-12">
            <h1>Contact Info</h1>
            <p>Hi everyone. I'm best reached anytime by email. Feel free to text or call M-F between 7am - 6pm.</p>
            <ul><li>Email : <strong>andrew@theninthbit.us</strong></li><li>Phone: <strong>808-428-7804</strong></li></ul>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <h1>Add a file</h1>
            <p>Sorry, for now, email me the file and I'll add it here</p>
        </div>
    </div>
    <div class="row" style="height:400px">
        <div class="col-md-6">
            <h1>Development Files</h1>
            <iframe id="devFiles" src="https://drive.google.com/embeddedfolderview?id=0B6KgMJraoDeoUmlTdXl3R2ZNUG8#list" width="100%" height="100%" frameborder="0"></iframe>
        </div>
        <div class="col-md-6">
            <h1>Planasa Files</h1>
            <iframe id="planasaFiles" src="https://drive.google.com/embeddedfolderview?id=0B6KgMJraoDeoZGRrTl9KQlZ5UkU#list" width="100%" height="100%" frameborder="0"></iframe>
        </div>
    </div>

</div>

</body>
</html>